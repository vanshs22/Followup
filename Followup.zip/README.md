# FollowUp CRM + Reactivation Bot (Demo-ready)

Full CRM + follow-up automation for gyms, med spas, and local businesses.

## Database: Supabase (Postgres)

Set `SUPABASE_DB_URL` in `.env` (see **SUPABASE.md** and `supabase/migrations/001_initial_schema.sql`).
Without it, the app falls back to local SQLite so you can still boot offline.

## Quick start (demo)

```bash
cd followup-bot
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open: **http://127.0.0.1:8000**

Demo data is created **automatically on first start** (no extra setup).

### Demo logins

| Role | Email | Password |
|------|--------|----------|
| Platform Admin | admin@followupbot.com | admin123 |
| FitLife Gym (client) | owner@fitlifegym.com | gym123 |
| Glow Med Spa (client) | owner@glowmedspa.com | spa123 |

### What is pre-loaded

- 2 businesses (gym + med spa)
- ~40 gym members + ~25 spa clients (Active / At-risk / Dormant / Churned)
- Follow-up sequences with multi-step messages
- Auto-reply rules
- Simulated messaging (no Twilio/Resend keys needed for demo)

See **DEMO.md** for a full click-through test script.

### Optional live channels

Set keys in **Admin → Client accounts → [business]** (not visible to clients).  
Or env vars — see `INTEGRATIONS.md`.

## Multi-user & concurrent access (SaaS-ready)

This is a **multi-tenant** platform:

| Layer | How it works |
|-------|----------------|
| **Platform admin** | One (or more) `role=admin` users. Manage all businesses, integrations, global bot runs. |
| **Client businesses** | Each business is isolated by `business_id`. Customers, sequences, messages, auto-replies never leak across tenants. |
| **Team members per business** | A client can invite additional users under **Settings → Team**. All share the same `business_id` and can log in and work **concurrently**. |
| **Auth** | Stateless JWT in an HttpOnly cookie. Works safely with multiple Gunicorn/Uvicorn workers. |
| **Bot concurrency** | On Postgres/Supabase, pending enrollment steps use `SELECT … FOR UPDATE SKIP LOCKED` so overlapping runs never double-send. |

### How to onboard multi users

1. **Admin onboards a new business**  
   Admin → Businesses → **New client business** → enter business name + owner email.  
   A temporary password is shown once. Share it with the owner.

2. **Owner invites team**  
   Owner logs in → Settings → **Team** → Invite teammate (email + optional name).  
   Temp password shown once; teammate can change it under Settings → General.

3. **Concurrent use**  
   Any number of team members can be signed in at the same time. All actions are scoped to their `business_id`. CSRF tokens and JWT keep forms and sessions safe.

4. **Deactivate**  
   From Team tab, deactivate a member (they can no longer log in). Data stays with the business.

## Before a real client uses this (not just the demo)

This build includes critical fixes from a full code audit — see **CHANGELOG.md**.  
Before onboarding a paying client:

1. Set `FOLLOWUP_SECRET` and `FOLLOWUP_ENCRYPTION_KEY` in `.env` (each its own value).
2. Set `SHOW_DEMO_LOGINS=false` so demo passwords are hidden.
3. Set `META_APP_SECRET` and `META_WHATSAPP_VERIFY_TOKEN` if using WhatsApp Cloud API.
4. Use **Admin → Businesses → New client business** to onboard (real flow exists).
5. Confirm the bot scheduler is running (startup log: "Bot scheduler started").
6. Prefer **Postgres / Supabase** in production (connection pooling + row locking).
7. For multi-worker deploys, put a reverse proxy (nginx/Caddy) in front and set `COOKIE_SECURE=true` (default) under HTTPS.

