from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Float, JSON
)
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.database import Base


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    CLIENT = "client"


class CustomerStatus(str, enum.Enum):
    ACTIVE = "active"
    AT_RISK = "at_risk"
    DORMANT = "dormant"
    CHURNED = "churned"
    NEW = "new"


class SequenceType(str, enum.Enum):
    FOLLOW_UP = "follow_up"
    REACTIVATION = "reactivation"
    WIN_BACK = "win_back"
    REBOOKING = "rebooking"
    NURTURE = "nurture"
    CUSTOM = "custom"


class Channel(str, enum.Enum):
    SMS = "sms"
    EMAIL = "email"
    WHATSAPP = "whatsapp"
    CALL = "call"


class EnrollmentStatus(str, enum.Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    FAILED = "failed"
    WON = "won"


class MessageStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    OPENED = "opened"
    CLICKED = "clicked"
    REPLIED = "replied"
    SIMULATED = "simulated"


class Business(Base):
    __tablename__ = "businesses"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    industry = Column(String(100), default="gym")
    email = Column(String(200))
    phone = Column(String(50))
    timezone = Column(String(50), default="UTC")
    logo_url = Column(String(500), nullable=True)
    settings = Column(JSON, default=dict)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    users = relationship("User", back_populates="business")
    customers = relationship("Customer", back_populates="business")
    sequences = relationship("Sequence", back_populates="business")
    notes = relationship("CustomerNote", back_populates="business")


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(200), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(200))
    role = Column(String(20), default=UserRole.CLIENT.value)
    business_id = Column(Integer, ForeignKey("businesses.id", ondelete="SET NULL"), nullable=True)
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    business = relationship("Business", back_populates="users")


class Customer(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    first_name = Column(String(100))
    last_name = Column(String(100))
    email = Column(String(200), index=True)
    phone = Column(String(50), index=True)
    status = Column(String(20), default=CustomerStatus.NEW.value, index=True)
    tags = Column(JSON, default=list)
    last_visit = Column(DateTime, nullable=True, index=True)
    total_visits = Column(Integer, default=0)
    lifetime_value = Column(Float, default=0.0)
    source = Column(String(100), nullable=True)
    notes = Column(Text, nullable=True)
    custom_fields = Column(JSON, default=dict)
    opted_out = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    last_reply_at = Column(DateTime, nullable=True)
    win_count = Column(Integer, default=0)
    # CRM extras
    address = Column(String(300), nullable=True)
    city = Column(String(100), nullable=True)
    birthday = Column(DateTime, nullable=True)
    assigned_to = Column(String(200), nullable=True)
    next_appointment = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    business = relationship("Business", back_populates="customers")
    enrollments = relationship("Enrollment", back_populates="customer")
    messages = relationship("MessageLog", back_populates="customer")
    note_entries = relationship("CustomerNote", back_populates="customer", cascade="all, delete-orphan")


class CustomerNote(Base):
    __tablename__ = "customer_notes"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    body = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    customer = relationship("Customer", back_populates="note_entries")
    business = relationship("Business", back_populates="notes")


class Sequence(Base):
    __tablename__ = "sequences"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    sequence_type = Column(String(50), default=SequenceType.FOLLOW_UP.value)
    is_active = Column(Boolean, default=True)
    is_template = Column(Boolean, default=False)
    trigger_rules = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    business = relationship("Business", back_populates="sequences")
    steps = relationship(
        "SequenceStep", back_populates="sequence",
        cascade="all, delete-orphan", order_by="SequenceStep.order",
    )
    enrollments = relationship("Enrollment", back_populates="sequence")


class SequenceStep(Base):
    __tablename__ = "sequence_steps"

    id = Column(Integer, primary_key=True, index=True)
    sequence_id = Column(Integer, ForeignKey("sequences.id", ondelete="CASCADE"), nullable=False)
    order = Column(Integer, default=1)
    delay_days = Column(Integer, default=0)
    delay_hours = Column(Integer, default=0)
    channel = Column(String(20), default=Channel.SMS.value)
    subject = Column(String(300), nullable=True)
    message_template = Column(Text, nullable=False)
    is_active = Column(Boolean, default=True)

    sequence = relationship("Sequence", back_populates="steps")


class Enrollment(Base):
    __tablename__ = "enrollments"

    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    sequence_id = Column(Integer, ForeignKey("sequences.id", ondelete="CASCADE"), nullable=False)
    status = Column(String(20), default=EnrollmentStatus.ACTIVE.value, index=True)
    current_step = Column(Integer, default=0)
    enrolled_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    next_action_at = Column(DateTime, nullable=True)
    metadata_ = Column("metadata", JSON, default=dict)
    won_at = Column(DateTime, nullable=True)
    win_note = Column(String(300), nullable=True)

    customer = relationship("Customer", back_populates="enrollments")
    sequence = relationship("Sequence", back_populates="enrollments")
    messages = relationship("MessageLog", back_populates="enrollment")


class MessageLog(Base):
    __tablename__ = "message_logs"

    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    enrollment_id = Column(Integer, ForeignKey("enrollments.id", ondelete="SET NULL"), nullable=True)
    channel = Column(String(20))
    direction = Column(String(10), default="outbound")
    subject = Column(String(300), nullable=True)
    content = Column(Text)
    status = Column(String(20), default=MessageStatus.PENDING.value)
    provider_detail = Column(String(300), nullable=True)
    external_id = Column(String(200), nullable=True, index=True)
    sent_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
    opened_at = Column(DateTime, nullable=True)
    replied_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    customer = relationship("Customer", back_populates="messages")
    enrollment = relationship("Enrollment", back_populates="messages")


class AutoReplyRule(Base):
    __tablename__ = "auto_reply_rules"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(200), default="Rule")
    keywords = Column(JSON, default=list)  # list of strings; match any
    channel = Column(String(20), default="any")  # any | sms | email | whatsapp
    reply_channel = Column(String(20), default="same")  # same | sms | email | whatsapp
    reply_template = Column(Text, nullable=False)
    is_active = Column(Boolean, default=True)
    priority = Column(Integer, default=10)
    created_at = Column(DateTime, default=datetime.utcnow)


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id", ondelete="SET NULL"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action = Column(String(100))
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = Column(String(64), nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    used_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
