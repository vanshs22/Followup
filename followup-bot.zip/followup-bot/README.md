# FollowUp + Reactivation Bot System

A complete, production-ready **Follow-up & Member Reactivation** automation platform inspired by Automiqo OS.

Built for **Gyms, Med Spas, Salons, HVAC, Home Services** and any local business that needs automated customer re-engagement.

## Features

### Client Portal
- Live dashboard with customer health metrics
- Customer list with status (Active / At-Risk / Dormant / Churned)
- Multi-step sequence builder view (Follow-up, Reactivation, Win-back)
- Auto-trigger rules (e.g. 30 days since last visit → Reactivation)
- Message log (SMS / Email / WhatsApp)
- One-click **Run Bot Now**

### Admin Portal
- Platform-wide overview
- All businesses & users management
- Global bot runner

### Bot Engine
- Automatic customer status calculation
- Rule-based auto-enrollment
- Multi-step sequence processor with delays
- Template variables (`{{first_name}}`, `{{business_name}}`, etc.)
- Simulated delivery (ready for Twilio / SendGrid)

## Quick Start

```bash
cd followup-bot
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open: **http://localhost:8000**

## Demo Accounts

| Role       | Email                     | Password  |
|------------|---------------------------|-----------|
| Admin      | admin@followupbot.com     | admin123  |
| Gym Owner  | owner@fitlifegym.com      | gym123    |
| Med Spa    | owner@glowmedspa.com      | spa123    |

## Tech Stack

- FastAPI + SQLAlchemy + SQLite
- Jinja2 + Tailwind CSS + Alpine.js
- JWT cookie auth
- Fully linked Client + Admin UIs
