from fastapi import FastAPI, Request, Depends, Form, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Optional
import os

from app.database import get_db, init_db, SessionLocal
from app.models import (
    User, Business, Customer, Sequence, SequenceStep, Enrollment,
    MessageLog, ActivityLog, CustomerStatus, EnrollmentStatus
)
from app.auth import (
    get_password_hash, verify_password, create_access_token,
    get_current_user, require_user, require_admin, require_client
)
from app.bot_engine import (
    get_dashboard_stats, auto_enroll_by_rules, process_pending_steps,
    enroll_customer, update_customer_statuses, calculate_customer_status
)
from app.seed import seed

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = FastAPI(title="FollowUp + Reactivation Bot", version="1.0.0")

app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))


@app.on_event("startup")
def on_startup():
    init_db()
    seed()


# ===================== AUTH =====================

@app.get("/", response_class=HTMLResponse)
async def root(request: Request, user: Optional[User] = Depends(get_current_user)):
    if user:
        if user.role == "admin":
            return RedirectResponse("/admin", status_code=302)
        return RedirectResponse("/client", status_code=302)
    return RedirectResponse("/login", status_code=302)


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, user: Optional[User] = Depends(get_current_user)):
    if user:
        return RedirectResponse("/", status_code=302)
    return templates.TemplateResponse("auth/login.html", {"request": request, "error": None})


@app.post("/login", response_class=HTMLResponse)
async def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(password, user.hashed_password):
        return templates.TemplateResponse(
            "auth/login.html",
            {"request": request, "error": "Invalid email or password"},
            status_code=400,
        )
    user.last_login = datetime.utcnow()
    db.commit()

    token = create_access_token(data={"sub": user.email})
    redirect_url = "/admin" if user.role == "admin" else "/client"
    response = RedirectResponse(redirect_url, status_code=302)
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        max_age=60 * 60 * 24 * 7,
        samesite="lax",
    )
    return response


@app.get("/logout")
async def logout():
    response = RedirectResponse("/login", status_code=302)
    response.delete_cookie("access_token")
    return response


# ===================== CLIENT PORTAL =====================

@app.get("/client", response_class=HTMLResponse)
async def client_dashboard(
    request: Request,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    if user.role == "admin":
        return RedirectResponse("/admin", status_code=302)
    stats = get_dashboard_stats(db, user.business_id)
    business = db.query(Business).filter(Business.id == user.business_id).first()

    recent_messages = (
        db.query(MessageLog)
        .join(Customer)
        .filter(Customer.business_id == user.business_id)
        .order_by(MessageLog.created_at.desc())
        .limit(8)
        .all()
    )
    active_enrollments = (
        db.query(Enrollment)
        .join(Customer)
        .filter(
            Customer.business_id == user.business_id,
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
        )
        .order_by(Enrollment.enrolled_at.desc())
        .limit(6)
        .all()
    )

    return templates.TemplateResponse("client/dashboard.html", {
        "request": request,
        "user": user,
        "business": business,
        "stats": stats,
        "recent_messages": recent_messages,
        "active_enrollments": active_enrollments,
        "page": "dashboard",
    })


@app.get("/client/customers", response_class=HTMLResponse)
async def client_customers(
    request: Request,
    status: Optional[str] = None,
    q: Optional[str] = None,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    query = db.query(Customer).filter(Customer.business_id == user.business_id)

    if status and status != "all":
        query = query.filter(Customer.status == status)
    if q:
        like = f"%{q}%"
        query = query.filter(
            (Customer.first_name.ilike(like)) |
            (Customer.last_name.ilike(like)) |
            (Customer.email.ilike(like)) |
            (Customer.phone.ilike(like))
        )

    customers = query.order_by(Customer.updated_at.desc()).limit(100).all()

    return templates.TemplateResponse("client/customers.html", {
        "request": request,
        "user": user,
        "business": business,
        "customers": customers,
        "current_status": status or "all",
        "q": q or "",
        "page": "customers",
    })


@app.post("/client/customers/add")
async def add_customer(
    request: Request,
    first_name: str = Form(...),
    last_name: str = Form(""),
    email: str = Form(""),
    phone: str = Form(""),
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    c = Customer(
        business_id=user.business_id,
        first_name=first_name,
        last_name=last_name,
        email=email or None,
        phone=phone or None,
        status=CustomerStatus.NEW.value,
    )
    db.add(c)
    db.commit()
    return RedirectResponse("/client/customers", status_code=302)


@app.get("/client/sequences", response_class=HTMLResponse)
async def client_sequences(
    request: Request,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    sequences = (
        db.query(Sequence)
        .filter(Sequence.business_id == user.business_id)
        .order_by(Sequence.created_at.desc())
        .all()
    )
    return templates.TemplateResponse("client/sequences.html", {
        "request": request,
        "user": user,
        "business": business,
        "sequences": sequences,
        "page": "sequences",
    })


@app.get("/client/sequences/{seq_id}", response_class=HTMLResponse)
async def client_sequence_detail(
    seq_id: int,
    request: Request,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    sequence = (
        db.query(Sequence)
        .filter(Sequence.id == seq_id, Sequence.business_id == user.business_id)
        .first()
    )
    if not sequence:
        raise HTTPException(404, "Sequence not found")

    enrollments = (
        db.query(Enrollment)
        .filter(Enrollment.sequence_id == sequence.id)
        .order_by(Enrollment.enrolled_at.desc())
        .limit(50)
        .all()
    )
    return templates.TemplateResponse("client/sequence_detail.html", {
        "request": request,
        "user": user,
        "business": business,
        "sequence": sequence,
        "enrollments": enrollments,
        "page": "sequences",
    })


@app.post("/client/sequences/{seq_id}/toggle")
async def toggle_sequence(
    seq_id: int,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    seq = db.query(Sequence).filter(
        Sequence.id == seq_id, Sequence.business_id == user.business_id
    ).first()
    if seq:
        seq.is_active = not seq.is_active
        db.commit()
    return RedirectResponse(f"/client/sequences/{seq_id}", status_code=302)


@app.post("/client/run-bot")
async def run_bot(
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    """Manually trigger status update + auto-enroll + process steps."""
    update_customer_statuses(db, user.business_id)
    enrolled = auto_enroll_by_rules(db, user.business_id)
    stats = process_pending_steps(db, user.business_id)
    return JSONResponse({
        "ok": True,
        "enrolled": enrolled,
        "processed": stats,
    })


@app.post("/client/enroll")
async def manual_enroll(
    customer_id: int = Form(...),
    sequence_id: int = Form(...),
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    customer = db.query(Customer).filter(
        Customer.id == customer_id, Customer.business_id == user.business_id
    ).first()
    sequence = db.query(Sequence).filter(
        Sequence.id == sequence_id, Sequence.business_id == user.business_id
    ).first()
    if customer and sequence:
        enroll_customer(db, customer, sequence, force=True)
    return RedirectResponse("/client/customers", status_code=302)


@app.get("/client/messages", response_class=HTMLResponse)
async def client_messages(
    request: Request,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    messages = (
        db.query(MessageLog)
        .join(Customer)
        .filter(Customer.business_id == user.business_id)
        .order_by(MessageLog.created_at.desc())
        .limit(100)
        .all()
    )
    return templates.TemplateResponse("client/messages.html", {
        "request": request,
        "user": user,
        "business": business,
        "messages": messages,
        "page": "messages",
    })


@app.get("/client/settings", response_class=HTMLResponse)
async def client_settings(
    request: Request,
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    return templates.TemplateResponse("client/settings.html", {
        "request": request,
        "user": user,
        "business": business,
        "page": "settings",
    })


# ===================== ADMIN PORTAL =====================

@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(
    request: Request,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    businesses = db.query(Business).all()
    total_customers = db.query(Customer).count()
    total_users = db.query(User).filter(User.role == "client").count()
    total_messages = db.query(MessageLog).count()
    active_enrollments = db.query(Enrollment).filter(
        Enrollment.status == EnrollmentStatus.ACTIVE.value
    ).count()

    return templates.TemplateResponse("admin/dashboard.html", {
        "request": request,
        "user": user,
        "businesses": businesses,
        "total_customers": total_customers,
        "total_users": total_users,
        "total_messages": total_messages,
        "active_enrollments": active_enrollments,
        "page": "dashboard",
    })


@app.get("/admin/businesses", response_class=HTMLResponse)
async def admin_businesses(
    request: Request,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    businesses = db.query(Business).order_by(Business.created_at.desc()).all()
    return templates.TemplateResponse("admin/businesses.html", {
        "request": request,
        "user": user,
        "businesses": businesses,
        "page": "businesses",
    })


@app.get("/admin/users", response_class=HTMLResponse)
async def admin_users(
    request: Request,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return templates.TemplateResponse("admin/users.html", {
        "request": request,
        "user": user,
        "users": users,
        "page": "users",
    })


@app.post("/admin/run-global-bot")
async def admin_run_bot(
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    businesses = db.query(Business).filter(Business.is_active == True).all()
    results = []
    for b in businesses:
        update_customer_statuses(db, b.id)
        enrolled = auto_enroll_by_rules(db, b.id)
        stats = process_pending_steps(db, b.id)
        results.append({"business": b.name, "enrolled": enrolled, "stats": stats})
    return JSONResponse({"ok": True, "results": results})


# ===================== API (for future / AJAX) =====================

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "FollowUp + Reactivation Bot"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)