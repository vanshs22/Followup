"""
Follow-up + Reactivation Bot Engine
Inspired by Automiqo OS revenue & customer_success workflows.
"""
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.models import (
    Customer, Sequence, SequenceStep, Enrollment, MessageLog,
    CustomerStatus, EnrollmentStatus, MessageStatus, SequenceType
)
from typing import List, Optional
import random


def render_template(template: str, customer: Customer, business_name: str = "us") -> str:
    """Simple template renderer with customer variables."""
    first = customer.first_name or "there"
    last = customer.last_name or ""
    full = f"{first} {last}".strip()
    return (
        template
        .replace("{{first_name}}", first)
        .replace("{{last_name}}", last)
        .replace("{{full_name}}", full)
        .replace("{{email}}", customer.email or "")
        .replace("{{phone}}", customer.phone or "")
        .replace("{{business_name}}", business_name)
        .replace("{{total_visits}}", str(customer.total_visits or 0))
    )


def calculate_customer_status(customer: Customer) -> str:
    """Auto-calculate status based on last_visit (Gym / MedSpa / Salon logic)."""
    if not customer.last_visit:
        return CustomerStatus.NEW.value

    days = (datetime.utcnow() - customer.last_visit).days

    if days <= 14:
        return CustomerStatus.ACTIVE.value
    elif days <= 30:
        return CustomerStatus.AT_RISK.value
    elif days <= 90:
        return CustomerStatus.DORMANT.value
    else:
        return CustomerStatus.CHURNED.value


def update_customer_statuses(db: Session, business_id: int):
    """Recalculate statuses for all customers of a business."""
    customers = db.query(Customer).filter(Customer.business_id == business_id).all()
    for c in customers:
        new_status = calculate_customer_status(c)
        if c.status != new_status:
            c.status = new_status
    db.commit()


def enroll_customer(
    db: Session,
    customer: Customer,
    sequence: Sequence,
    force: bool = False,
) -> Optional[Enrollment]:
    """Enroll a customer into a sequence if not already active in it."""
    existing = (
        db.query(Enrollment)
        .filter(
            Enrollment.customer_id == customer.id,
            Enrollment.sequence_id == sequence.id,
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
        )
        .first()
    )
    if existing and not force:
        return existing

    # Cancel previous active enrollments of same type if needed
    if not force:
        active = (
            db.query(Enrollment)
            .filter(
                Enrollment.customer_id == customer.id,
                Enrollment.status == EnrollmentStatus.ACTIVE.value,
            )
            .all()
        )
        for e in active:
            if e.sequence.sequence_type == sequence.sequence_type:
                e.status = EnrollmentStatus.CANCELLED.value

    first_step = (
        db.query(SequenceStep)
        .filter(SequenceStep.sequence_id == sequence.id, SequenceStep.is_active == True)
        .order_by(SequenceStep.order)
        .first()
    )

    next_action = datetime.utcnow()
    if first_step:
        next_action += timedelta(days=first_step.delay_days, hours=first_step.delay_hours)

    enrollment = Enrollment(
        customer_id=customer.id,
        sequence_id=sequence.id,
        status=EnrollmentStatus.ACTIVE.value,
        current_step=0,
        next_action_at=next_action,
    )
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return enrollment


def auto_enroll_by_rules(db: Session, business_id: int) -> int:
    """
    Auto-enroll customers based on sequence trigger_rules.
    Inspired by Automiqo dormant member reactivation + win-back logic.
    """
    sequences = (
        db.query(Sequence)
        .filter(Sequence.business_id == business_id, Sequence.is_active == True)
        .all()
    )
    enrolled_count = 0

    for seq in sequences:
        rules = seq.trigger_rules or {}
        if not rules:
            continue

        query = db.query(Customer).filter(Customer.business_id == business_id)

        # Status filter
        if "status" in rules:
            query = query.filter(Customer.status == rules["status"])

        # Days since last visit
        if "days_since_last_visit" in rules:
            cutoff = datetime.utcnow() - timedelta(days=int(rules["days_since_last_visit"]))
            query = query.filter(Customer.last_visit <= cutoff)

        # Min lifetime value
        if "min_ltv" in rules:
            query = query.filter(Customer.lifetime_value >= float(rules["min_ltv"]))

        # Tags
        if "has_tag" in rules:
            # Simple JSON contains check (SQLite limited)
            pass

        candidates = query.all()
        for customer in candidates:
            # Skip if already active in this sequence
            existing = (
                db.query(Enrollment)
                .filter(
                    Enrollment.customer_id == customer.id,
                    Enrollment.sequence_id == seq.id,
                    Enrollment.status == EnrollmentStatus.ACTIVE.value,
                )
                .first()
            )
            if existing:
                continue

            enroll_customer(db, customer, seq)
            enrolled_count += 1

    return enrolled_count


def process_pending_steps(db: Session, business_id: Optional[int] = None) -> dict:
    """
    Process all enrollments that are due for the next step.
    This is the core bot runner (can be called by cron / scheduler).
    """
    now = datetime.utcnow()
    query = (
        db.query(Enrollment)
        .filter(
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
            Enrollment.next_action_at <= now,
        )
    )
    if business_id:
        query = query.join(Customer).filter(Customer.business_id == business_id)

    due = query.all()
    stats = {"processed": 0, "sent": 0, "completed": 0, "failed": 0}

    for enrollment in due:
        result = process_enrollment_step(db, enrollment)
        stats["processed"] += 1
        if result == "sent":
            stats["sent"] += 1
        elif result == "completed":
            stats["completed"] += 1
        elif result == "failed":
            stats["failed"] += 1

    return stats


def process_enrollment_step(db: Session, enrollment: Enrollment) -> str:
    """Send the next step of a sequence for one enrollment."""
    sequence = enrollment.sequence
    steps = (
        db.query(SequenceStep)
        .filter(SequenceStep.sequence_id == sequence.id, SequenceStep.is_active == True)
        .order_by(SequenceStep.order)
        .all()
    )

    if not steps or enrollment.current_step >= len(steps):
        enrollment.status = EnrollmentStatus.COMPLETED.value
        enrollment.completed_at = datetime.utcnow()
        db.commit()
        return "completed"

    step = steps[enrollment.current_step]
    customer = enrollment.customer
    business_name = customer.business.name if customer.business else "us"

    content = render_template(step.message_template, customer, business_name)
    subject = None
    if step.subject:
        subject = render_template(step.subject, customer, business_name)

    # Simulate sending (in production: Twilio / SendGrid / WhatsApp API)
    success = simulate_send(step.channel, customer, content)

    log = MessageLog(
        customer_id=customer.id,
        enrollment_id=enrollment.id,
        channel=step.channel,
        subject=subject,
        content=content,
        status=MessageStatus.SENT.value if success else MessageStatus.FAILED.value,
        sent_at=datetime.utcnow() if success else None,
        error_message=None if success else "Simulated delivery failure",
    )
    db.add(log)

    if success:
        enrollment.current_step += 1

        # Schedule next step
        if enrollment.current_step < len(steps):
            next_step = steps[enrollment.current_step]
            enrollment.next_action_at = datetime.utcnow() + timedelta(
                days=next_step.delay_days, hours=next_step.delay_hours
            )
        else:
            enrollment.status = EnrollmentStatus.COMPLETED.value
            enrollment.completed_at = datetime.utcnow()
            enrollment.next_action_at = None

        db.commit()
        return "sent"
    else:
        db.commit()
        return "failed"


def simulate_send(channel: str, customer: Customer, content: str) -> bool:
    """Simulate message delivery (95% success rate)."""
    # In real system: integrate Twilio, SendGrid, WhatsApp Business API, VAPI
    if channel == "sms" and not customer.phone:
        return False
    if channel == "email" and not customer.email:
        return False
    return random.random() > 0.05  # 95% success


def get_dashboard_stats(db: Session, business_id: int) -> dict:
    """Aggregate stats for client dashboard."""
    customers = db.query(Customer).filter(Customer.business_id == business_id).all()
    total = len(customers)
    by_status = {}
    for s in CustomerStatus:
        by_status[s.value] = sum(1 for c in customers if c.status == s.value)

    active_enrollments = (
        db.query(Enrollment)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
        )
        .count()
    )

    completed_this_month = (
        db.query(Enrollment)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            Enrollment.status == EnrollmentStatus.COMPLETED.value,
            Enrollment.completed_at >= datetime.utcnow().replace(day=1, hour=0, minute=0),
        )
        .count()
    )

    messages_this_month = (
        db.query(MessageLog)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            MessageLog.sent_at >= datetime.utcnow().replace(day=1, hour=0, minute=0),
        )
        .count()
    )

    reactivated = (
        db.query(Customer)
        .filter(
            Customer.business_id == business_id,
            Customer.status == CustomerStatus.ACTIVE.value,
            Customer.updated_at >= datetime.utcnow() - timedelta(days=30),
        )
        .count()
    )

    return {
        "total_customers": total,
        "by_status": by_status,
        "active_enrollments": active_enrollments,
        "completed_this_month": completed_this_month,
        "messages_this_month": messages_this_month,
        "reactivated_approx": reactivated,
    }