# FollowUp CRM + Reactivation Bot (Demo-ready)

Full CRM + follow-up automation for gyms, med spas, and local businesses.

## Database: Supabase (Postgres)

Set `SUPABASE_DB_URL` in `.env` (see **SUPABASE.md** and `supabase/migrations/001_initial_schema.sql`).
Without it, the app falls back to local SQLite so you can still boot offline.

## Quick start (demo)

```bash
cd followup-bot
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open: **http://127.0.0.1:8000**

Demo data is created **automatically on first start** (no extra setup).

### Demo logins

| Role | Email | Password |
|------|--------|----------|
| Platform Admin | admin@followupbot.com | admin123 |
| FitLife Gym (client) | owner@fitlifegym.com | gym123 |
| Glow Med Spa (client) | owner@glowmedspa.com | spa123 |

### What is pre-loaded

- 2 businesses (gym + med spa)
- ~40 gym members + ~25 spa clients (Active / At-risk / Dormant / Churned)
- Follow-up sequences with multi-step messages
- Auto-reply rules
- Simulated messaging (no Twilio/Resend keys needed for demo)

See **DEMO.md** for a full click-through test script.

### Optional live channels

Set keys in **Admin → Client accounts → [business]** (not visible to clients).  
Or env vars — see `INTEGRATIONS.md`.

## Before a real client uses this (not just the demo)

This build fixed a set of critical bugs found in a full code audit — see
**CHANGELOG.md** for the complete list with rationale. Before onboarding a
paying client:

1. Set `FOLLOWUP_SECRET` and `FOLLOWUP_ENCRYPTION_KEY` in `.env` (each its own
   value — don't leave them unset).
2. Set `SHOW_DEMO_LOGINS=false` so the demo passwords aren't public.
3. Set `META_APP_SECRET` and `META_WHATSAPP_VERIFY_TOKEN` if you're using
   WhatsApp via Meta's Cloud API.
4. Use **Admin → Businesses → New client business** to onboard them (a real
   onboarding flow now exists — previously only the two seeded demo
   businesses could exist at all).
5. Confirm the bot scheduler is running (it starts automatically — see
   startup log for "Bot scheduler started"). Previously sequences only sent
   when someone manually clicked a button.

