"""
Helpers for keeping customer + visit data in the FollowUp DB.
Used by: CSV import UI, REST API, and external tools (n8n / Zapier / booking systems).
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from sqlalchemy.orm import Session

from app.models import Customer, CustomerStatus, Business
from app.bot_engine import calculate_customer_status


def parse_date(value: Any) -> Optional[datetime]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip()
    for fmt in (
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%m-%d-%Y",
    ):
        try:
            return datetime.strptime(s[:19].replace("Z", ""), fmt.replace("Z", ""))
        except Exception:
            continue
    try:
        # dateutil-ish fallback: fromisoformat
        return datetime.fromisoformat(s.replace("Z", ""))
    except Exception:
        return None


def _normalize_phone_10(phone: Optional[str]) -> str:
    if not phone:
        return ""
    digits = "".join(x for x in phone if x.isdigit())
    return digits[-10:] if digits else ""


class CustomerIndex:
    """
    In-memory lookup index (external_id / email / normalized phone) built
    once per bulk import.

    PERF FIX: import_csv_rows() used to call find_customer() per row, which
    ran a full Python-side scan of every existing customer for the business
    on every row (no way to do the phone match in SQL because of the digit-
    normalization). For a business with a few thousand members, importing a
    few thousand rows was O(rows x existing_customers) plus a DB round trip
    per row — slow, and since every route here runs synchronous DB calls
    inline on the asyncio event loop, a big import could stall the whole app
    for every other business's users for its entire duration. Building this
    index once up front turns each row's lookup into an O(1) dict hit.
    """

    def __init__(self, db: Session, business_id: int):
        self.by_external_id: Dict[str, Customer] = {}
        self.by_email: Dict[str, Customer] = {}
        self.by_phone: Dict[str, Customer] = {}
        for c in db.query(Customer).filter(Customer.business_id == business_id).all():
            self.register(c)

    def register(self, c: Customer) -> None:
        cf = c.custom_fields if isinstance(c.custom_fields, dict) else {}
        if cf.get("external_id"):
            self.by_external_id[str(cf["external_id"])] = c
        if c.email:
            self.by_email[c.email.strip().lower()] = c
        p10 = _normalize_phone_10(c.phone)
        if p10:
            self.by_phone[p10] = c

    def find(
        self, *, email: Optional[str] = None, phone: Optional[str] = None,
        external_id: Optional[str] = None,
    ) -> Optional[Customer]:
        if external_id and str(external_id) in self.by_external_id:
            return self.by_external_id[str(external_id)]
        if email:
            hit = self.by_email.get(email.strip().lower())
            if hit:
                return hit
        if phone:
            p10 = _normalize_phone_10(phone)
            if p10 and p10 in self.by_phone:
                return self.by_phone[p10]
        return None


def find_customer(
    db: Session,
    business_id: int,
    *,
    email: Optional[str] = None,
    phone: Optional[str] = None,
    external_id: Optional[str] = None,
    index: Optional[CustomerIndex] = None,
) -> Optional[Customer]:
    if index is not None:
        return index.find(email=email, phone=phone, external_id=external_id)
    q = db.query(Customer).filter(Customer.business_id == business_id)
    if external_id:
        # stored in custom_fields.external_id
        for c in q.all():
            cf = c.custom_fields or {}
            if isinstance(cf, dict) and str(cf.get("external_id")) == str(external_id):
                return c
    if email:
        c = q.filter(Customer.email == email.strip().lower()).first()
        if c:
            return c
    if phone:
        digits = "".join(x for x in phone if x.isdigit())
        if digits:
            for c in q.all():
                if c.phone and "".join(x for x in c.phone if x.isdigit()).endswith(digits[-10:]):
                    return c
    return None


def upsert_customer(
    db: Session,
    business_id: int,
    data: Dict[str, Any],
    *,
    index: Optional[CustomerIndex] = None,
    commit: bool = True,
) -> Tuple[Customer, bool]:
    """
    Create or update a customer.
    Match order: external_id → email → phone.
    Returns (customer, created: bool).

    Pass `index` (a CustomerIndex) and `commit=False` when bulk-importing so
    lookups stay O(1) and the transaction can be committed in batches instead
    of once per row — see import_csv_rows().
    """
    email = (data.get("email") or "").strip().lower() or None
    phone = (data.get("phone") or "").strip() or None
    external_id = data.get("external_id") or data.get("id")
    if external_id is not None:
        external_id = str(external_id)

    existing = find_customer(
        db, business_id, email=email, phone=phone, external_id=external_id, index=index
    )
    created = existing is None
    c = existing or Customer(business_id=business_id)

    if data.get("first_name") is not None:
        c.first_name = str(data.get("first_name") or "").strip() or c.first_name
    if data.get("last_name") is not None:
        c.last_name = str(data.get("last_name") or "").strip() or c.last_name
    if email:
        c.email = email
    if phone:
        c.phone = phone
    if data.get("source"):
        c.source = str(data["source"])
    if data.get("notes"):
        c.notes = str(data["notes"])
    if data.get("tags") is not None:
        tags = data["tags"]
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",") if t.strip()]
        c.tags = tags
    if data.get("lifetime_value") is not None:
        try:
            c.lifetime_value = float(data["lifetime_value"])
        except Exception:
            pass
    if data.get("total_visits") is not None:
        try:
            c.total_visits = int(data["total_visits"])
        except Exception:
            pass

    last_visit = parse_date(data.get("last_visit") or data.get("last_checkin"))
    if last_visit:
        c.last_visit = last_visit

    cf = c.custom_fields if isinstance(c.custom_fields, dict) else {}
    if external_id:
        cf["external_id"] = external_id
    # merge any extra custom fields
    extra = data.get("custom_fields")
    if isinstance(extra, dict):
        cf.update(extra)
    c.custom_fields = cf

    c.status = calculate_customer_status(c)
    c.updated_at = datetime.utcnow()

    if created:
        db.add(c)

    if commit:
        db.commit()
        db.refresh(c)
    else:
        # Assign a PK without committing so later rows in the same batch can
        # still see this customer via the index (e.g. duplicate rows for the
        # same person within one CSV).
        db.flush()

    if index is not None:
        index.register(c)

    return c, created


def record_visit(
    db: Session,
    business_id: int,
    *,
    email: Optional[str] = None,
    phone: Optional[str] = None,
    external_id: Optional[str] = None,
    visited_at: Optional[datetime] = None,
    add_ltv: float = 0,
) -> Optional[Customer]:
    """Check-in / visit: bump last_visit + total_visits, optionally LTV."""
    c = find_customer(db, business_id, email=email, phone=phone, external_id=external_id)
    if not c:
        return None
    when = visited_at or datetime.utcnow()
    c.last_visit = when
    c.total_visits = (c.total_visits or 0) + 1
    if add_ltv:
        c.lifetime_value = (c.lifetime_value or 0) + float(add_ltv)
    c.status = calculate_customer_status(c)
    c.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(c)
    return c


def import_csv_rows(
    db: Session,
    business_id: int,
    rows: List[Dict[str, Any]],
) -> Dict[str, int]:
    """Bulk upsert from list of dicts (CSV headers normalized)."""
    stats = {"created": 0, "updated": 0, "skipped": 0}
    index = CustomerIndex(db, business_id)
    batch_size = 200
    since_commit = 0
    for raw in rows:
        # normalize keys
        row = {str(k).strip().lower().replace(" ", "_"): v for k, v in raw.items()}
        # aliases
        if "firstname" in row and "first_name" not in row:
            row["first_name"] = row["firstname"]
        if "lastname" in row and "last_name" not in row:
            row["last_name"] = row["lastname"]
        if "mobile" in row and "phone" not in row:
            row["phone"] = row["mobile"]
        if "last_check_in" in row and "last_visit" not in row:
            row["last_visit"] = row["last_check_in"]

        if not row.get("email") and not row.get("phone") and not row.get("first_name"):
            stats["skipped"] += 1
            continue
        _, created = upsert_customer(db, business_id, row, index=index, commit=False)
        if created:
            stats["created"] += 1
        else:
            stats["updated"] += 1
        since_commit += 1
        if since_commit >= batch_size:
            db.commit()
            since_commit = 0
    db.commit()
    return stats
