"""
Real messaging integrations:
  - Twilio  → SMS (+ optional WhatsApp via Twilio)
  - Resend  → Email
  - n8n / WhatsApp Business Cloud API → WhatsApp

Credentials are read from environment first, then per-business settings JSON.
If a provider is not configured, that channel falls back to simulation (logged as simulated).
"""
from __future__ import annotations

import os
import json
import base64
import logging
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

import httpx

from app.crypto import decrypt_value, SECRET_SETTING_KEYS

logger = logging.getLogger("followup.integrations")


def _biz_settings(business) -> dict:
    if not business:
        return {}
    s = business.settings or {}
    if isinstance(s, str):
        try:
            s = json.loads(s)
        except Exception:
            s = {}
    return s if isinstance(s, dict) else {}


def get_channel_config(business, channel: str) -> Dict[str, Any]:
    """Merge env defaults with business.settings.integrations (decrypting secrets)."""
    env = {
        "twilio_account_sid": os.environ.get("TWILIO_ACCOUNT_SID", ""),
        "twilio_auth_token": os.environ.get("TWILIO_AUTH_TOKEN", ""),
        "twilio_from_number": os.environ.get("TWILIO_FROM_NUMBER", ""),
        "twilio_whatsapp_from": os.environ.get("TWILIO_WHATSAPP_FROM", ""),  # e.g. whatsapp:+1415...
        "resend_api_key": os.environ.get("RESEND_API_KEY", ""),
        "resend_from_email": os.environ.get("RESEND_FROM_EMAIL", "FollowUp <onboarding@resend.dev>"),
        "n8n_whatsapp_webhook": os.environ.get("N8N_WHATSAPP_WEBHOOK", ""),
        "meta_whatsapp_token": os.environ.get("META_WHATSAPP_TOKEN", ""),
        "meta_whatsapp_phone_id": os.environ.get("META_WHATSAPP_PHONE_ID", ""),
        "simulate_if_missing": os.environ.get("FOLLOWUP_SIMULATE", "true").lower() in ("1", "true", "yes"),
    }
    biz = _biz_settings(business).get("integrations", {}) or {}
    # business overrides env (secrets are stored encrypted — decrypt on read)
    for k, v in biz.items():
        if not v:
            continue
        env[k] = decrypt_value(v) if k in SECRET_SETTING_KEYS else v
    env["channel"] = channel
    return env


def send_message(
    channel: str,
    to: str,
    content: str,
    *,
    subject: Optional[str] = None,
    business=None,
    customer=None,
    metadata: Optional[dict] = None,
) -> Tuple[bool, str, Optional[str]]:
    """
    Send via real provider. Returns (success, status_detail, external_id).
    status_detail is human-readable; external_id is provider message SID/id if any.
    """
    channel = (channel or "sms").lower()
    cfg = get_channel_config(business, channel)
    metadata = metadata or {}

    if channel == "sms":
        return _send_twilio_sms(to, content, cfg)
    if channel == "email":
        return _send_resend_email(to, subject or "Message from us", content, cfg, business)
    if channel == "whatsapp":
        return _send_whatsapp(to, content, cfg, metadata)
    if channel == "call":
        return False, "Voice calls not configured yet", None
    return False, f"Unknown channel: {channel}", None


def _send_twilio_sms(to: str, body: str, cfg: dict) -> Tuple[bool, str, Optional[str]]:
    sid = cfg.get("twilio_account_sid") or ""
    token = cfg.get("twilio_auth_token") or ""
    from_num = cfg.get("twilio_from_number") or ""
    if not (sid and token and from_num):
        if cfg.get("simulate_if_missing", True):
            return True, "simulated:sms (Twilio not configured)", f"sim_{datetime.utcnow().timestamp()}"
        return False, "Twilio not configured", None
    if not to:
        return False, "No phone number", None
    to_norm = _normalize_phone(to)
    try:
        with httpx.Client(timeout=20.0) as client:
            r = client.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
                auth=(sid, token),
                data={"From": from_num, "To": to_norm, "Body": body},
            )
        if r.status_code in (200, 201):
            data = r.json()
            return True, "sent:twilio", data.get("sid")
        # Bad credentials / forbidden → optional simulate so demos still work
        if r.status_code in (401, 403) and cfg.get("simulate_if_missing", True):
            return True, f"simulated:sms (twilio auth {r.status_code})", f"sim_{datetime.utcnow().timestamp()}"
        return False, f"twilio_error:{r.status_code}:{r.text[:200]}", None
    except Exception as e:
        logger.exception("Twilio SMS failed")
        if cfg.get("simulate_if_missing", True):
            return True, f"simulated:sms (twilio exception)", f"sim_{datetime.utcnow().timestamp()}"
        return False, f"twilio_exception:{e}", None


def _send_resend_email(
    to: str, subject: str, body: str, cfg: dict, business=None
) -> Tuple[bool, str, Optional[str]]:
    key = cfg.get("resend_api_key") or ""
    from_email = cfg.get("resend_from_email") or "FollowUp <onboarding@resend.dev>"
    if not key:
        if cfg.get("simulate_if_missing", True):
            return True, "simulated:email (Resend not configured)", f"sim_{datetime.utcnow().timestamp()}"
        return False, "Resend not configured", None
    if not to:
        return False, "No email address", None
    # plain text → simple HTML
    html = body.replace("\n", "<br>\n")
    payload = {
        "from": from_email,
        "to": [to],
        "subject": subject,
        "text": body,
        "html": f"<div style='font-family:sans-serif;line-height:1.5'>{html}</div>",
    }
    try:
        with httpx.Client(timeout=20.0) as client:
            r = client.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json=payload,
            )
        if r.status_code in (200, 201):
            data = r.json()
            return True, "sent:resend", data.get("id")
        if r.status_code in (401, 403) and cfg.get("simulate_if_missing", True):
            return True, f"simulated:email (resend auth {r.status_code})", f"sim_{datetime.utcnow().timestamp()}"
        return False, f"resend_error:{r.status_code}:{r.text[:200]}", None
    except Exception as e:
        logger.exception("Resend failed")
        if cfg.get("simulate_if_missing", True):
            return True, f"simulated:email (resend exception)", f"sim_{datetime.utcnow().timestamp()}"
        return False, f"resend_exception:{e}", None


def _send_whatsapp(to: str, body: str, cfg: dict, metadata: dict) -> Tuple[bool, str, Optional[str]]:
    """
    Priority:
      1) n8n webhook (N8N_WHATSAPP_WEBHOOK) — recommended for WhatsApp Business automation
      2) Meta Cloud API (token + phone number id)
      3) Twilio WhatsApp (twilio_whatsapp_from)
      4) Simulate
    """
    if not to:
        return False, "No phone for WhatsApp", None
    to_norm = _normalize_phone(to)

    # 1) n8n
    webhook = cfg.get("n8n_whatsapp_webhook") or ""
    if webhook:
        try:
            with httpx.Client(timeout=25.0) as client:
                # Payload shaped for n8n WhatsApp "Send message" workflows
                # (compatible with Coach AI Chatbot / Meta Cloud API style fields)
                r = client.post(
                    webhook,
                    json={
                        "to": to_norm,
                        "phone": to_norm,
                        "recipientPhoneNumber": to_norm.lstrip("+"),
                        "message": body,
                        "text": body,
                        "textBody": body,
                        "channel": "whatsapp",
                        "messaging_product": "whatsapp",
                        "type": "text",
                        "phone_number_id": (metadata or {}).get("phone_number_id") or cfg.get("meta_whatsapp_phone_id") or "",
                        "metadata": metadata or {},
                        "timestamp": datetime.utcnow().isoformat() + "Z",
                    },
                )
            if r.status_code < 400:
                return True, "sent:n8n_whatsapp", r.headers.get("x-message-id") or f"n8n_{datetime.utcnow().timestamp()}"
            return False, f"n8n_error:{r.status_code}:{r.text[:200]}", None
        except Exception as e:
            logger.exception("n8n WhatsApp failed")
            return False, f"n8n_exception:{e}", None

    # 2) Meta Cloud API
    token = cfg.get("meta_whatsapp_token") or ""
    phone_id = cfg.get("meta_whatsapp_phone_id") or ""
    if token and phone_id:
        try:
            with httpx.Client(timeout=20.0) as client:
                r = client.post(
                    f"https://graph.facebook.com/v19.0/{phone_id}/messages",
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                    json={
                        "messaging_product": "whatsapp",
                        "to": to_norm.lstrip("+"),
                        "type": "text",
                        "text": {"body": body},
                    },
                )
            if r.status_code < 400:
                data = r.json()
                mid = None
                try:
                    mid = data["messages"][0]["id"]
                except Exception:
                    mid = str(data)
                return True, "sent:meta_whatsapp", mid
            return False, f"meta_error:{r.status_code}:{r.text[:200]}", None
        except Exception as e:
            logger.exception("Meta WhatsApp failed")
            return False, f"meta_exception:{e}", None

    # 3) Twilio WhatsApp
    sid = cfg.get("twilio_account_sid") or ""
    auth = cfg.get("twilio_auth_token") or ""
    wa_from = cfg.get("twilio_whatsapp_from") or ""
    if sid and auth and wa_from:
        try:
            with httpx.Client(timeout=20.0) as client:
                r = client.post(
                    f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
                    auth=(sid, auth),
                    data={
                        "From": wa_from if wa_from.startswith("whatsapp:") else f"whatsapp:{wa_from}",
                        "To": f"whatsapp:{to_norm}",
                        "Body": body,
                    },
                )
            if r.status_code in (200, 201):
                data = r.json()
                return True, "sent:twilio_whatsapp", data.get("sid")
            return False, f"twilio_wa_error:{r.status_code}:{r.text[:200]}", None
        except Exception as e:
            logger.exception("Twilio WhatsApp failed")
            return False, f"twilio_wa_exception:{e}", None

    if cfg.get("simulate_if_missing", True):
        return True, "simulated:whatsapp (no provider configured)", f"sim_{datetime.utcnow().timestamp()}"
    return False, "WhatsApp not configured (set n8n webhook, Meta, or Twilio WA)", None


def _normalize_phone(phone: str) -> str:
    p = "".join(c for c in (phone or "") if c.isdigit() or c == "+")
    if p and not p.startswith("+"):
        # assume US if 10 digits
        if len(p) == 10:
            p = "+1" + p
        else:
            p = "+" + p
    return p


def verify_twilio_signature(auth_token: str, url: str, params: dict, signature: str) -> bool:
    """
    Validate an inbound Twilio webhook per Twilio's spec:
    https://www.twilio.com/docs/usage/security#validating-requests
    Signature = base64(HMAC-SHA1(auth_token, url + concat(sorted(key+value)))).
    Implemented directly (no twilio SDK dependency) to keep requirements light.
    """
    if not auth_token or not signature:
        return False
    import hashlib
    import hmac as _hmac

    data = url
    for key in sorted(params.keys()):
        data += key + str(params[key])
    computed = base64.b64encode(
        _hmac.new(auth_token.encode("utf-8"), data.encode("utf-8"), hashlib.sha1).digest()
    ).decode("utf-8")
    return _hmac.compare_digest(computed, signature)


def verify_meta_signature(app_secret: str, raw_body: bytes, signature_header: str) -> bool:
    """
    Validate an inbound Meta (WhatsApp Cloud API) webhook.
    https://developers.facebook.com/docs/graph-api/webhooks/getting-started#verification-requests
    Header looks like "sha256=<hex digest>".
    """
    if not app_secret or not signature_header:
        return False
    import hashlib
    import hmac as _hmac

    try:
        _, sig = signature_header.split("=", 1)
    except ValueError:
        return False
    computed = _hmac.new(app_secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
    return _hmac.compare_digest(computed, sig)


def find_business_by_twilio_number(db_session, to_number: str):
    """
    Resolve which client business owns a Twilio 'To' number, so inbound
    webhooks can be scoped to the right tenant instead of scanning every
    customer across every business.
    """
    from app.models import Business

    norm_to = _normalize_phone(to_number or "")
    if not norm_to:
        return None
    for b in db_session.query(Business).filter(Business.is_active == True).all():
        cfg = get_channel_config(b, "sms")
        for candidate in (cfg.get("twilio_from_number"), cfg.get("twilio_whatsapp_from")):
            if candidate and _normalize_phone(str(candidate).replace("whatsapp:", "")) == norm_to:
                return b
    return None


def send_platform_email(to: str, subject: str, body: str) -> Tuple[bool, str, Optional[str]]:
    """
    Platform-level email (password resets, account notices) — uses the
    platform's own Resend key, not a business's per-tenant one. Falls back to
    simulation (logged, not sent) if PLATFORM_RESEND_API_KEY isn't set, same
    as every other channel in this file.
    """
    cfg = {
        "resend_api_key": os.environ.get("PLATFORM_RESEND_API_KEY", ""),
        "resend_from_email": os.environ.get("PLATFORM_FROM_EMAIL", "FollowUp <onboarding@resend.dev>"),
        "simulate_if_missing": os.environ.get("FOLLOWUP_SIMULATE", "true").lower() in ("1", "true", "yes"),
    }
    return _send_resend_email(to, subject, body, cfg)


def integration_status(business=None) -> Dict[str, Any]:
    """For settings UI — which providers are live."""
    cfg = get_channel_config(business, "sms")
    return {
        "sms": {
            "provider": "twilio" if cfg.get("twilio_account_sid") and cfg.get("twilio_auth_token") and cfg.get("twilio_from_number") else "simulated",
            "configured": bool(cfg.get("twilio_account_sid") and cfg.get("twilio_from_number")),
        },
        "email": {
            "provider": "resend" if cfg.get("resend_api_key") else "simulated",
            "configured": bool(cfg.get("resend_api_key")),
        },
        "whatsapp": {
            "provider": (
                "n8n" if cfg.get("n8n_whatsapp_webhook")
                else "meta" if cfg.get("meta_whatsapp_token") and cfg.get("meta_whatsapp_phone_id")
                else "twilio" if cfg.get("twilio_whatsapp_from")
                else "simulated"
            ),
            "configured": bool(
                cfg.get("n8n_whatsapp_webhook")
                or (cfg.get("meta_whatsapp_token") and cfg.get("meta_whatsapp_phone_id"))
                or cfg.get("twilio_whatsapp_from")
            ),
        },
    }
