from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Request, Depends, Form, HTTPException, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.orm.attributes import flag_modified
from datetime import datetime
from typing import Optional
import os, csv, io, secrets, re, json

from app.database import get_db, init_db
from app.models import (
    User, Business, Customer, Sequence, SequenceStep, Enrollment,
    MessageLog, CustomerNote, AutoReplyRule, CustomerStatus, EnrollmentStatus, SequenceType, Channel
)
from app.auth import (
    verify_password, create_access_token, get_password_hash,
    get_current_user, require_user, require_admin, require_client,
    check_login_rate_limit, record_login_failure, clear_login_failures,
)
from app.bot_engine import (
    get_dashboard_stats, auto_enroll_by_rules, process_pending_steps,
    enroll_customer, update_customer_statuses, record_inbound_reply, send_one_off
)
from app.integrations import (
    integration_status, get_channel_config, verify_twilio_signature,
    verify_meta_signature, find_business_by_twilio_number,
)
from app.crypto import encrypt_value, decrypt_value, SECRET_SETTING_KEYS
from app import ai_writer
from app.data_sync import upsert_customer, record_visit, import_csv_rows
from app.seed import seed

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(title="FollowUp CRM + Reactivation", version="3.0.0")
os.makedirs(os.path.join(BASE_DIR, "static", "css"), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "static", "js"), exist_ok=True)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@app.exception_handler(HTTPException)
async def friendly_http_exception_handler(request: Request, exc: HTTPException):
    """
    FIX: many /client and /admin POST routes (add_customer, edit_customer,
    add_sequence_step, create_sequence, manual_enroll, quick_send, etc.)
    raise a plain HTTPException on bad input. With no handler registered,
    that surfaced as a bare `{"detail": "..."}` JSON blob to someone mid a
    normal HTML form flow. /api/* and /webhooks/* consumers still expect and
    get JSON — only the browser-facing routes get the friendly page.
    """
    path = request.url.path
    if path.startswith("/api/") or path.startswith("/webhooks/"):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    if exc.status_code in (401,):
        return RedirectResponse("/login", status_code=302)
    return templates.TemplateResponse(
        "error.html",
        {"request": request, "status_code": exc.status_code, "detail": exc.detail},
        status_code=exc.status_code,
    )


_scheduler = None


@app.on_event("startup")
def on_startup():
    from app.database import DB_BACKEND, DATABASE_URL
    backend = init_db()
    print(f"Database backend: {backend}")
    if backend == "sqlite":
        print("  Tip: set SUPABASE_DB_URL for Supabase Postgres (see SUPABASE.md)")
    seed()
    _seed_auto_replies()

    # BUGFIX (critical): previously there was no scheduler anywhere in this
    # app — sequence steps only ever advanced when a human clicked "Run Bot
    # Now" or "Run global bot". For a product whose entire pitch is automated
    # follow-up, that meant nothing actually sent itself. This runs the same
    # logic as /admin/run-global-bot on an interval automatically.
    # Set BOT_SCHEDULER_ENABLED=false to disable (e.g. if you're driving runs
    # from an external cron/n8n Schedule Trigger instead).
    global _scheduler
    if os.environ.get("BOT_SCHEDULER_ENABLED", "true").lower() in ("1", "true", "yes"):
        try:
            from apscheduler.schedulers.background import BackgroundScheduler

            interval_minutes = int(os.environ.get("BOT_SCHEDULER_INTERVAL_MINUTES", "10"))

            def _scheduled_run():
                db = next(get_db())
                try:
                    results = _run_bot_for_all_businesses(db)
                    total_sent = sum(r["stats"].get("sent", 0) + r["stats"].get("simulated", 0) for r in results)
                    if total_sent:
                        print(f"[scheduler] bot run: {total_sent} message(s) sent/simulated across {len(results)} business(es)")
                except Exception as e:
                    print(f"[scheduler] bot run failed: {e}")
                finally:
                    db.close()

            _scheduler = BackgroundScheduler()
            _scheduler.add_job(_scheduled_run, "interval", minutes=interval_minutes, id="followup_bot_run", max_instances=1)
            _scheduler.start()
            print(f"Bot scheduler started — running every {interval_minutes} minute(s). Set BOT_SCHEDULER_ENABLED=false to disable.")
        except ImportError:
            print("⚠️  apscheduler not installed — automated bot runs are disabled. Install it (see requirements.txt) or run BOT_SCHEDULER_ENABLED=false and trigger /admin/run-global-bot from an external cron/n8n instead.")


@app.on_event("shutdown")
def on_shutdown():
    if _scheduler:
        _scheduler.shutdown(wait=False)


def _seed_auto_replies():
    db = next(get_db())
    try:
        if db.query(AutoReplyRule).count() == 0:
            for bid in [b.id for b in db.query(Business).all()]:
                db.add(AutoReplyRule(
                    business_id=bid, name="Booking interest",
                    keywords=["book", "yes", "schedule", "appointment"],
                    channel="any", reply_channel="same",
                    reply_template="Great {{first_name}}! Reply with a day/time that works, or book here: https://example.com/book — {{business_name}}",
                    priority=1,
                ))
                db.add(AutoReplyRule(
                    business_id=bid, name="Pricing question",
                    keywords=["price", "cost", "how much", "pricing"],
                    channel="any", reply_channel="same",
                    reply_template="Hi {{first_name}}, happy to help on pricing. Our team will follow up shortly — or call us anytime. — {{business_name}}",
                    priority=5,
                ))
            db.commit()
    finally:
        db.close()


# ===================== AUTH =====================

@app.get("/", response_class=HTMLResponse)
async def root(request: Request, user: Optional[User] = Depends(get_current_user)):
    if user:
        return RedirectResponse("/admin" if user.role == "admin" else "/client", status_code=302)
    return RedirectResponse("/login", status_code=302)


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, user: Optional[User] = Depends(get_current_user)):
    if user:
        return RedirectResponse("/", status_code=302)
    show_demo = os.environ.get("SHOW_DEMO_LOGINS", "true").lower() in ("1", "true", "yes")
    return templates.TemplateResponse("auth/login.html", {"request": request, "error": None, "show_demo_creds": show_demo})


@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request, email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    email = (email or "").strip().lower()
    show_demo = os.environ.get("SHOW_DEMO_LOGINS", "true").lower() in ("1", "true", "yes")
    # SECURITY: basic brute-force guard. Keyed by client IP + email so one bad
    # actor can't lock out a real user, but repeated attempts against the same
    # email from anywhere get slowed down. In-memory only — fine for a single
    # process, but a multi-worker/replica deployment needs a shared store
    # (e.g. Redis) for this to actually hold across all instances.
    rl_key = f"{request.client.host if request.client else 'unknown'}:{email}"
    if not check_login_rate_limit(rl_key):
        return templates.TemplateResponse(
            "auth/login.html",
            {"request": request, "error": "Too many attempts. Please wait a few minutes and try again.", "show_demo_creds": show_demo},
            status_code=429,
        )
    user = db.query(User).filter(User.email == email).first()
    if not user or not user.is_active or not verify_password(password, user.hashed_password):
        record_login_failure(rl_key)
        return templates.TemplateResponse("auth/login.html", {"request": request, "error": "Invalid email or password", "show_demo_creds": show_demo}, status_code=400)
    clear_login_failures(rl_key)
    user.last_login = datetime.utcnow()
    db.commit()
    token = create_access_token(data={"sub": user.email})
    resp = RedirectResponse("/admin" if user.role == "admin" else "/client", status_code=302)
    resp.set_cookie(key="access_token", value=token, httponly=True, max_age=60*60*24*7, samesite="lax", path="/")
    return resp


@app.get("/logout")
async def logout():
    resp = RedirectResponse("/login", status_code=302)
    resp.delete_cookie("access_token", path="/")
    return resp


# ===================== CLIENT CRM =====================

@app.get("/client", response_class=HTMLResponse)
async def client_dashboard(request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    # require_client now strictly enforces role == "client" (403s admins
    # before this body ever runs), so the old "if admin, redirect" branch
    # that used to live here is gone — see app/auth.py.
    if not user.business_id:
        raise HTTPException(400, "No business linked")
    stats = get_dashboard_stats(db, user.business_id)
    business = db.query(Business).filter(Business.id == user.business_id).first()
    integ = integration_status(business)
    recent_messages = (
        db.query(MessageLog).options(joinedload(MessageLog.customer))
        .join(Customer).filter(Customer.business_id == user.business_id)
        .order_by(MessageLog.created_at.desc()).limit(10).all()
    )
    active_enrollments = (
        db.query(Enrollment).options(joinedload(Enrollment.customer), joinedload(Enrollment.sequence))
        .join(Customer).filter(Customer.business_id == user.business_id, Enrollment.status == EnrollmentStatus.ACTIVE.value)
        .order_by(Enrollment.enrolled_at.desc()).limit(8).all()
    )
    recent_wins = (
        db.query(Enrollment).options(joinedload(Enrollment.customer), joinedload(Enrollment.sequence))
        .join(Customer).filter(Customer.business_id == user.business_id, Enrollment.status == EnrollmentStatus.WON.value)
        .order_by(Enrollment.won_at.desc()).limit(5).all()
    )
    return templates.TemplateResponse("client/dashboard.html", {
        "request": request, "user": user, "business": business, "stats": stats,
        "integrations": integ, "recent_messages": recent_messages,
        "active_enrollments": active_enrollments, "recent_wins": recent_wins, "page": "dashboard",
    })


@app.get("/client/customers", response_class=HTMLResponse)
async def client_customers(
    request: Request, status: Optional[str] = None, q: Optional[str] = None, tag: Optional[str] = None,
    user: User = Depends(require_client), db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    query = db.query(Customer).filter(Customer.business_id == user.business_id)
    if status and status != "all":
        query = query.filter(Customer.status == status)
    if q:
        like = f"%{q.strip()}%"
        query = query.filter(
            (Customer.first_name.ilike(like)) | (Customer.last_name.ilike(like)) |
            (Customer.email.ilike(like)) | (Customer.phone.ilike(like))
        )
    customers = query.order_by(Customer.updated_at.desc()).limit(200).all()
    if tag:
        customers = [c for c in customers if tag.lower() in [str(t).lower() for t in (c.tags or [])]]
    sequences = db.query(Sequence).filter(Sequence.business_id == user.business_id, Sequence.is_active == True).all()
    return templates.TemplateResponse("client/customers.html", {
        "request": request, "user": user, "business": business, "customers": customers,
        "sequences": sequences, "current_status": status or "all", "q": q or "", "page": "customers",
    })


@app.get("/client/customers/{customer_id}", response_class=HTMLResponse)
async def client_customer_detail(
    customer_id: int, request: Request, user: User = Depends(require_client), db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.business_id == user.business_id).first()
    if not customer:
        raise HTTPException(404, "Customer not found")
    enrollments = (
        db.query(Enrollment).options(joinedload(Enrollment.sequence))
        .filter(Enrollment.customer_id == customer.id).order_by(Enrollment.enrolled_at.desc()).all()
    )
    messages = (
        db.query(MessageLog).filter(MessageLog.customer_id == customer.id)
        .order_by(MessageLog.created_at.asc()).limit(100).all()
    )
    notes = (
        db.query(CustomerNote).filter(CustomerNote.customer_id == customer.id)
        .order_by(CustomerNote.created_at.desc()).limit(30).all()
    )
    sequences = db.query(Sequence).filter(Sequence.business_id == user.business_id, Sequence.is_active == True).all()
    return templates.TemplateResponse("client/customer_detail.html", {
        "request": request, "user": user, "business": business, "customer": customer,
        "enrollments": enrollments, "messages": messages, "notes": notes,
        "sequences": sequences, "page": "customers",
    })


@app.post("/client/customers/add")
async def add_customer(
    first_name: str = Form(...), last_name: str = Form(""), email: str = Form(""), phone: str = Form(""),
    user: User = Depends(require_client), db: Session = Depends(get_db),
):
    first_name = first_name.strip()
    if not first_name:
        raise HTTPException(400, "First name required")
    email = (email or "").strip().lower() or None
    if email and not EMAIL_RE.match(email):
        raise HTTPException(400, "Invalid email")
    c = Customer(
        business_id=user.business_id, first_name=first_name,
        last_name=(last_name or "").strip(), email=email,
        phone=(phone or "").strip() or None, status=CustomerStatus.NEW.value,
    )
    db.add(c)
    db.commit()
    return RedirectResponse("/client/customers?added=1", status_code=302)


@app.post("/client/customers/import")
async def import_customers_csv(request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    form = await request.form()
    file = form.get("file")
    if not file or not hasattr(file, "read"):
        return RedirectResponse("/client/import?import_error=1", status_code=302)
    raw = await file.read()
    if len(raw) > 5_000_000:
        return RedirectResponse("/client/import?import_error=1", status_code=302)
    try:
        text_csv = raw.decode("utf-8-sig")
    except Exception:
        text_csv = raw.decode("latin-1", errors="ignore")
    rows = list(csv.DictReader(io.StringIO(text_csv)))
    stats = import_csv_rows(db, user.business_id, rows[:5000])
    return RedirectResponse(
        f"/client/import?imported=1&created={stats['created']}&updated={stats['updated']}&skipped={stats['skipped']}",
        status_code=302,
    )


@app.post("/client/customers/{customer_id}/visit")
async def client_record_visit(customer_id: int, user: User = Depends(require_client), db: Session = Depends(get_db)):
    c = db.query(Customer).filter(Customer.id == customer_id, Customer.business_id == user.business_id).first()
    if not c:
        raise HTTPException(404)
    from app.bot_engine import calculate_customer_status
    c.last_visit = datetime.utcnow()
    c.total_visits = (c.total_visits or 0) + 1
    c.status = calculate_customer_status(c)
    c.updated_at = datetime.utcnow()
    db.commit()
    return RedirectResponse(f"/client/customers/{customer_id}?visit=1", status_code=302)


@app.post("/client/customers/{customer_id}/note")
async def add_note(
    customer_id: int, body: str = Form(...),
    user: User = Depends(require_client), db: Session = Depends(get_db),
):
    c = db.query(Customer).filter(Customer.id == customer_id, Customer.business_id == user.business_id).first()
    if not c:
        raise HTTPException(404)
    body = (body or "").strip()
    if not body:
        return RedirectResponse(f"/client/customers/{customer_id}", status_code=302)
    db.add(CustomerNote(business_id=user.business_id, customer_id=c.id, user_id=user.id, body=body[:5000]))
    db.commit()
    return RedirectResponse(f"/client/customers/{customer_id}?note=1", status_code=302)


@app.post("/client/customers/{customer_id}/send")
async def quick_send(
    customer_id: int,
    channel: str = Form("sms"),
    content: str = Form(...),
    subject: str = Form(""),
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    c = db.query(Customer).filter(Customer.id == customer_id, Customer.business_id == user.business_id).first()
    if not c:
        raise HTTPException(404)
    if c.opted_out:
        return RedirectResponse(f"/client/customers/{customer_id}?opted_out=1", status_code=302)
    channel = channel if channel in ("sms", "email", "whatsapp") else "sms"
    content = (content or "").strip()
    if not content or len(content) > 4000:
        raise HTTPException(400, "Invalid message")
    send_one_off(db, c, channel, content, subject=subject or None)
    return RedirectResponse(f"/client/customers/{customer_id}?sent=1", status_code=302)


@app.post("/client/customers/{customer_id}/edit")
async def edit_customer(
    customer_id: int,
    first_name: str = Form(...), last_name: str = Form(""),
    email: str = Form(""), phone: str = Form(""),
    tags: str = Form(""), notes: str = Form(""),
    user: User = Depends(require_client), db: Session = Depends(get_db),
):
    c = db.query(Customer).filter(Customer.id == customer_id, Customer.business_id == user.business_id).first()
    if not c:
        raise HTTPException(404)
    c.first_name = first_name.strip()
    c.last_name = (last_name or "").strip()
    email = (email or "").strip().lower() or None
    if email and not EMAIL_RE.match(email):
        raise HTTPException(400, "Invalid email")
    c.email = email
    c.phone = (phone or "").strip() or None
    c.tags = [t.strip() for t in (tags or "").split(",") if t.strip()]
    c.notes = (notes or "").strip() or None
    c.updated_at = datetime.utcnow()
    db.commit()
    return RedirectResponse(f"/client/customers/{customer_id}?saved=1", status_code=302)



@app.get("/client/import", response_class=HTMLResponse)
async def client_import_page(request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    settings = business.settings if business and isinstance(business.settings, dict) else {}
    return templates.TemplateResponse("client/import.html", {
        "request": request, "user": user, "business": business,
        "settings": settings, "page": "import",
    })


@app.get("/client/sequences", response_class=HTMLResponse)
async def client_sequences(request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    sequences = (
        db.query(Sequence).options(joinedload(Sequence.steps))
        .filter(Sequence.business_id == user.business_id).order_by(Sequence.created_at.desc()).all()
    )
    return templates.TemplateResponse("client/sequences.html", {
        "request": request, "user": user, "business": business, "sequences": sequences, "page": "sequences",
    })


@app.get("/client/sequences/{seq_id}", response_class=HTMLResponse)
async def client_sequence_detail(seq_id: int, request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    sequence = (
        db.query(Sequence).options(joinedload(Sequence.steps))
        .filter(Sequence.id == seq_id, Sequence.business_id == user.business_id).first()
    )
    if not sequence:
        raise HTTPException(404)
    enrollments = (
        db.query(Enrollment).options(joinedload(Enrollment.customer))
        .filter(Enrollment.sequence_id == sequence.id).order_by(Enrollment.enrolled_at.desc()).limit(50).all()
    )
    return templates.TemplateResponse("client/sequence_detail.html", {
        "request": request, "user": user, "business": business, "sequence": sequence,
        "enrollments": enrollments, "page": "sequences",
    })


@app.post("/client/sequences/{seq_id}/toggle")
async def toggle_sequence(seq_id: int, user: User = Depends(require_client), db: Session = Depends(get_db)):
    seq = db.query(Sequence).filter(Sequence.id == seq_id, Sequence.business_id == user.business_id).first()
    if seq:
        seq.is_active = not seq.is_active
        db.commit()
    return RedirectResponse(f"/client/sequences/{seq_id}", status_code=302)


@app.post("/client/sequences/create")
async def create_sequence(
    name: str = Form(...),
    sequence_type: str = Form("follow_up"),
    description: str = Form(""),
    use_ai: str = Form(""),
    num_steps: int = Form(3),
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    name = (name or "").strip()
    if not name:
        raise HTTPException(400, "Name required")
    seq = Sequence(
        business_id=user.business_id,
        name=name,
        description=(description or "").strip() or None,
        sequence_type=sequence_type if sequence_type in [e.value for e in SequenceType] else SequenceType.FOLLOW_UP.value,
        is_active=True,
        trigger_rules={},
    )
    db.add(seq)
    db.flush()
    if use_ai == "1" or (business and ai_writer.ai_enabled_for_sequences(business)):
        plan = ai_writer.generate_sequence_plan(
            business, sequence_name=name, sequence_type=seq.sequence_type, num_steps=int(num_steps or 3),
        )
        for st in plan:
            db.add(SequenceStep(
                sequence_id=seq.id, order=st["order"], delay_days=st["delay_days"],
                delay_hours=st.get("delay_hours") or 0, channel=st["channel"],
                subject=st.get("subject"), message_template=st["message_template"], is_active=True,
            ))
    else:
        db.add(SequenceStep(
            sequence_id=seq.id, order=1, delay_days=0, delay_hours=0, channel="sms",
            message_template="Hi {{first_name}}, thanks for visiting {{business_name}}! How was your experience?",
            is_active=True,
        ))
    db.commit()
    return RedirectResponse(f"/client/sequences/{seq.id}", status_code=302)


@app.post("/client/sequences/{seq_id}/steps")
async def add_sequence_step(
    seq_id: int,
    channel: str = Form("sms"),
    delay_days: int = Form(0),
    delay_hours: int = Form(0),
    subject: str = Form(""),
    message_template: str = Form(...),
    use_ai: str = Form(""),
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    seq = db.query(Sequence).filter(Sequence.id == seq_id, Sequence.business_id == user.business_id).first()
    if not seq:
        raise HTTPException(404)
    business = db.query(Business).filter(Business.id == user.business_id).first()
    order = (max([s.order for s in seq.steps], default=0) + 1) if seq.steps else 1
    channel = channel if channel in ("sms", "email", "whatsapp") else "sms"
    msg = (message_template or "").strip()
    subj = (subject or "").strip() or None
    if use_ai == "1" or (not msg and business and ai_writer.ai_enabled_for_sequences(business)):
        gen = ai_writer.generate_sequence_step_message(
            business, sequence_name=seq.name, sequence_type=seq.sequence_type,
            step_order=order, channel=channel, delay_days=int(delay_days or 0),
            total_steps=order,
        )
        msg = gen["message_template"]
        if channel == "email":
            subj = gen.get("subject") or subj
    if not msg:
        raise HTTPException(400, "Message required")
    db.add(SequenceStep(
        sequence_id=seq.id, order=order, delay_days=int(delay_days or 0),
        delay_hours=int(delay_hours or 0), channel=channel, subject=subj,
        message_template=msg, is_active=True,
    ))
    db.commit()
    return RedirectResponse(f"/client/sequences/{seq_id}", status_code=302)


@app.post("/client/sequences/{seq_id}/ai-fill")
async def ai_fill_sequence(seq_id: int, user: User = Depends(require_client), db: Session = Depends(get_db)):
    seq = db.query(Sequence).options(joinedload(Sequence.steps)).filter(
        Sequence.id == seq_id, Sequence.business_id == user.business_id
    ).first()
    if not seq:
        raise HTTPException(404)
    business = db.query(Business).filter(Business.id == user.business_id).first()
    # clear existing steps and rebuild with AI
    for st in list(seq.steps or []):
        db.delete(st)
    db.flush()
    plan = ai_writer.generate_sequence_plan(
        business, sequence_name=seq.name, sequence_type=seq.sequence_type, num_steps=3,
    )
    for st in plan:
        db.add(SequenceStep(
            sequence_id=seq.id, order=st["order"], delay_days=st["delay_days"],
            delay_hours=0, channel=st["channel"], subject=st.get("subject"),
            message_template=st["message_template"], is_active=True,
        ))
    db.commit()
    return RedirectResponse(f"/client/sequences/{seq_id}?ai=1", status_code=302)


@app.post("/client/auto-replies")
async def create_auto_reply(
    name: str = Form("Rule"),
    keywords: str = Form(...),
    channel: str = Form("any"),
    reply_channel: str = Form("same"),
    reply_template: str = Form(...),
    use_ai: str = Form(""),
    user: User = Depends(require_client),
    db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    kws = [k.strip() for k in (keywords or "").split(",") if k.strip()]
    body = (reply_template or "").strip()
    if use_ai == "1" or (not body and business and ai_writer.ai_enabled_for_auto_reply(business)):
        body = ai_writer.generate_auto_reply(
            business, inbound_text=", ".join(kws) or "hello", channel="sms",
            customer_first_name="{{first_name}}",
        )
    if not body:
        raise HTTPException(400, "Reply template required")
    db.add(AutoReplyRule(
        business_id=user.business_id, name=(name or "Rule").strip(),
        keywords=kws, channel=channel or "any", reply_channel=reply_channel or "same",
        reply_template=body, is_active=True, priority=10,
    ))
    db.commit()
    return RedirectResponse("/client/settings?rule=1", status_code=302)


@app.post("/client/auto-replies/{rule_id}/toggle")
async def toggle_auto_reply(rule_id: int, user: User = Depends(require_client), db: Session = Depends(get_db)):
    rule = db.query(AutoReplyRule).filter(
        AutoReplyRule.id == rule_id, AutoReplyRule.business_id == user.business_id
    ).first()
    if rule:
        rule.is_active = not rule.is_active
        db.commit()
    return RedirectResponse("/client/settings", status_code=302)


@app.post("/client/auto-replies/{rule_id}/delete")
async def delete_auto_reply(rule_id: int, user: User = Depends(require_client), db: Session = Depends(get_db)):
    rule = db.query(AutoReplyRule).filter(
        AutoReplyRule.id == rule_id, AutoReplyRule.business_id == user.business_id
    ).first()
    if rule:
        db.delete(rule)
        db.commit()
    return RedirectResponse("/client/settings", status_code=302)


@app.post("/client/run-bot")
async def run_bot(user: User = Depends(require_client), db: Session = Depends(get_db)):
    status_changed = update_customer_statuses(db, user.business_id)
    enrolled = auto_enroll_by_rules(db, user.business_id)
    stats = process_pending_steps(db, user.business_id)
    return JSONResponse({"ok": True, "status_changed": status_changed, "enrolled": enrolled, "processed": stats})


@app.post("/client/enroll")
async def manual_enroll(
    customer_id: int = Form(...), sequence_id: int = Form(...),
    user: User = Depends(require_client), db: Session = Depends(get_db),
):
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.business_id == user.business_id).first()
    sequence = db.query(Sequence).filter(Sequence.id == sequence_id, Sequence.business_id == user.business_id).first()
    if not customer or not sequence:
        raise HTTPException(404, "Customer or sequence not found")
    result = enroll_customer(db, customer, sequence, force=True)
    # BUGFIX: enroll_customer() returns None if the customer has opted out,
    # but this endpoint previously ignored that and always redirected with
    # ?enrolled=1 — showing a false "success" banner even when nothing
    # happened. Reflect the real outcome instead.
    param = "enrolled=1" if result else "enroll_error=opted_out"
    return RedirectResponse(f"/client/customers/{customer_id}?{param}", status_code=302)


@app.get("/client/messages", response_class=HTMLResponse)
async def client_messages(
    request: Request, direction: Optional[str] = None,
    user: User = Depends(require_client), db: Session = Depends(get_db),
):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    q = db.query(MessageLog).options(joinedload(MessageLog.customer)).join(Customer).filter(Customer.business_id == user.business_id)
    if direction in ("inbound", "outbound"):
        q = q.filter(MessageLog.direction == direction)
    messages = q.order_by(MessageLog.created_at.desc()).limit(150).all()
    return templates.TemplateResponse("client/messages.html", {
        "request": request, "user": user, "business": business, "messages": messages,
        "direction": direction or "all", "page": "messages",
    })


@app.get("/client/analytics", response_class=HTMLResponse)
async def client_analytics(request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    stats = get_dashboard_stats(db, user.business_id)
    msgs = db.query(MessageLog).join(Customer).filter(Customer.business_id == user.business_id, MessageLog.direction == "outbound").all()
    by_channel, by_status = {}, {}
    for m in msgs:
        by_channel[m.channel] = by_channel.get(m.channel, 0) + 1
        by_status[m.status] = by_status.get(m.status, 0) + 1
    wins = (
        db.query(Enrollment).options(joinedload(Enrollment.customer), joinedload(Enrollment.sequence))
        .join(Customer).filter(Customer.business_id == user.business_id, Enrollment.status == EnrollmentStatus.WON.value)
        .order_by(Enrollment.won_at.desc()).limit(20).all()
    )
    return templates.TemplateResponse("client/analytics.html", {
        "request": request, "user": user, "business": business, "stats": stats,
        "by_channel": by_channel, "by_status": by_status, "wins": wins, "page": "analytics",
    })


@app.get("/client/settings", response_class=HTMLResponse)
async def client_settings(request: Request, user: User = Depends(require_client), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    integ = integration_status(business)
    settings = dict(business.settings) if business and isinstance(business.settings, dict) else {}
    if settings.get("api_key"):
        # Stored encrypted at rest; this is the client's own credential so
        # it's fine (and necessary) to decrypt it back for them to copy.
        settings["api_key"] = decrypt_value(settings["api_key"])
    rules = db.query(AutoReplyRule).filter(AutoReplyRule.business_id == user.business_id).order_by(AutoReplyRule.priority).all()
    return templates.TemplateResponse("client/settings.html", {
        "request": request, "user": user, "business": business, "integrations": integ,
        "settings": settings, "rules": rules, "page": "settings", "saved": False,
    })


@app.post("/client/settings/api-key")
async def regenerate_api_key(user: User = Depends(require_client), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == user.business_id).first()
    if not business:
        raise HTTPException(404)
    s = dict(business.settings) if isinstance(business.settings, dict) else {}
    new_key = secrets.token_urlsafe(24)
    s["api_key"] = encrypt_value(new_key)
    business.settings = s
    flag_modified(business, "settings")
    db.commit()
    return RedirectResponse("/client/settings?api_key=1", status_code=302)



# ===================== WEBHOOKS =====================

def _parse_whatsapp_inbound(data: dict) -> dict:
    """
    Accept multiple shapes:
      - Simple: {from, message, business_id}
      - n8n WhatsApp Trigger (Coach AI Chatbot style):
          messages[0].text.body, messages[0].from, contacts[0], metadata.phone_number_id
      - Meta Cloud API webhook: entry[].changes[].value.messages[]
    """
    if not isinstance(data, dict):
        return {"phone": None, "content": "", "external_id": None, "business_id": None}

    # Simple flat
    phone = data.get("from") or data.get("phone") or data.get("recipientPhoneNumber")
    content = data.get("message") or data.get("text") or data.get("body") or data.get("textBody") or ""
    if isinstance(content, dict):
        content = content.get("body") or content.get("text") or ""
    external_id = data.get("id") or data.get("message_id") or data.get("MessageSid")
    business_id = data.get("business_id")

    # n8n WhatsApp Trigger shape
    messages = data.get("messages")
    if isinstance(messages, list) and messages:
        m0 = messages[0] if isinstance(messages[0], dict) else {}
        phone = phone or m0.get("from")
        text = m0.get("text") if isinstance(m0.get("text"), dict) else {}
        content = content or text.get("body") or m0.get("body") or ""
        external_id = external_id or m0.get("id")

    contacts = data.get("contacts")
    if not phone and isinstance(contacts, list) and contacts:
        c0 = contacts[0] if isinstance(contacts[0], dict) else {}
        phone = c0.get("wa_id") or c0.get("user_id") or phone

    # Meta nested webhook
    if not content or not phone:
        for entry in data.get("entry") or []:
            if not isinstance(entry, dict):
                continue
            for change in entry.get("changes") or []:
                if not isinstance(change, dict):
                    continue
                value = change.get("value") or {}
                for m in value.get("messages") or []:
                    if not isinstance(m, dict):
                        continue
                    phone = phone or m.get("from")
                    text = m.get("text") if isinstance(m.get("text"), dict) else {}
                    content = content or text.get("body") or ""
                    external_id = external_id or m.get("id")
                    break

    return {
        "phone": phone,
        "content": (content or "").strip(),
        "external_id": external_id,
        "business_id": int(business_id) if business_id not in (None, "") else None,
    }


@app.post("/webhooks/twilio/sms")
async def twilio_sms_webhook(request: Request, db: Session = Depends(get_db)):
    """Twilio SMS inbound — set Twilio console webhook to this URL."""
    form = await request.form()
    form_dict = dict(form)
    to_number = form.get("To", "")
    business = find_business_by_twilio_number(db, to_number)

    # SECURITY: verify this actually came from Twilio using that business's
    # own auth token, so the webhook URL can't be used by a stranger to
    # spoof inbound messages (fake "STOP"/"YES" replies, cost-abuse of the
    # AI auto-reply pipeline, etc). Falls back to permissive-if-unconfigured
    # so local/demo setups without a real Twilio account keep working.
    if business:
        cfg = get_channel_config(business, "sms")
        auth_token = cfg.get("twilio_auth_token")
        signature = request.headers.get("X-Twilio-Signature", "")
        if auth_token and not verify_twilio_signature(auth_token, str(request.url), form_dict, signature):
            raise HTTPException(status_code=403, detail="Invalid Twilio signature")

    # BUGFIX: business_id was previously never passed here, so
    # record_inbound_reply scanned every customer across every tenant and
    # matched on phone digits alone — a real risk if the same person is a
    # customer of two different businesses on this platform. Resolving the
    # tenant from the Twilio "To" number scopes the match correctly.
    record_inbound_reply(
        db,
        phone=form.get("From", ""),
        content=form.get("Body", ""),
        channel="sms",
        external_id=form.get("MessageSid"),
        business_id=business.id if business else None,
    )
    return HTMLResponse('<?xml version="1.0" encoding="UTF-8"?><Response></Response>', media_type="application/xml")


@app.post("/webhooks/twilio/whatsapp")
async def twilio_whatsapp_webhook(request: Request, db: Session = Depends(get_db)):
    """Twilio WhatsApp inbound (From like whatsapp:+1...)."""
    form = await request.form()
    form_dict = dict(form)
    frm = (form.get("From") or "").replace("whatsapp:", "")
    to_number = (form.get("To") or "").replace("whatsapp:", "")
    business = find_business_by_twilio_number(db, to_number)

    if business:
        cfg = get_channel_config(business, "whatsapp")
        auth_token = cfg.get("twilio_auth_token")
        signature = request.headers.get("X-Twilio-Signature", "")
        if auth_token and not verify_twilio_signature(auth_token, str(request.url), form_dict, signature):
            raise HTTPException(status_code=403, detail="Invalid Twilio signature")

    record_inbound_reply(
        db,
        phone=frm,
        content=form.get("Body", ""),
        channel="whatsapp",
        external_id=form.get("MessageSid"),
        business_id=business.id if business else None,
    )
    return HTMLResponse('<?xml version="1.0" encoding="UTF-8"?><Response></Response>', media_type="application/xml")


@app.post("/webhooks/n8n/whatsapp")
async def n8n_whatsapp_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Inbound from n8n (Coach AI Chatbot style) or simple JSON.
    Wire n8n: WhatsApp Trigger → HTTP Request POST to this URL (and optionally AI Agent before/after).
    """
    try:
        data = await request.json()
    except Exception:
        data = {}
    parsed = _parse_whatsapp_inbound(data if isinstance(data, dict) else {})
    if not parsed["content"] and not parsed["phone"]:
        return JSONResponse({"ok": True, "matched": False, "reason": "empty"})
    log = record_inbound_reply(
        db,
        phone=parsed["phone"],
        content=parsed["content"],
        channel="whatsapp",
        external_id=parsed["external_id"],
        business_id=parsed["business_id"],
    )
    return JSONResponse({
        "ok": True,
        "matched": log is not None,
        "customer_id": log.customer_id if log else None,
    })


@app.post("/webhooks/meta/whatsapp")
async def meta_whatsapp_webhook(request: Request, db: Session = Depends(get_db)):
    """Meta Cloud API webhook (GET verify + POST messages)."""
    raw_body = await request.body()
    app_secret = os.environ.get("META_APP_SECRET", "").strip()
    if app_secret:
        # SECURITY: without this, anyone who learns the webhook URL could
        # POST fabricated WhatsApp events and trigger opt-outs, fake wins,
        # or paid AI auto-replies. Only enforced when META_APP_SECRET is
        # configured, so demo/local setups without a real Meta app keep working.
        signature = request.headers.get("X-Hub-Signature-256", "")
        if not verify_meta_signature(app_secret, raw_body, signature):
            raise HTTPException(status_code=403, detail="Invalid Meta signature")
    try:
        data = json.loads(raw_body) if raw_body else {}
    except Exception:
        data = {}
    parsed = _parse_whatsapp_inbound(data if isinstance(data, dict) else {})
    log = None
    if parsed["content"] or parsed["phone"]:
        log = record_inbound_reply(
            db,
            phone=parsed["phone"],
            content=parsed["content"],
            channel="whatsapp",
            external_id=parsed["external_id"],
            business_id=parsed["business_id"],
        )
    return JSONResponse({"ok": True, "matched": log is not None})


@app.get("/webhooks/meta/whatsapp")
async def meta_whatsapp_verify(request: Request):
    """Meta webhook verification challenge."""
    params = request.query_params
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")
    # BUGFIX: previously defaulted to the guessable literal "followup_verify"
    # if META_WHATSAPP_VERIFY_TOKEN wasn't set. Now requires it to be
    # configured — verification will simply fail (safely) until you set one.
    expected = os.environ.get("META_WHATSAPP_VERIFY_TOKEN", "").strip()
    if expected and mode == "subscribe" and token == expected and challenge:
        return HTMLResponse(content=challenge)
    raise HTTPException(403, "Verification failed")


@app.post("/webhooks/resend")
async def resend_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Resend inbound / events. For reply emails, use Resend inbound if configured.
    Accepts: {from, text, html, subject, email_id}
    """
    try:
        data = await request.json()
    except Exception:
        data = {}
    # Resend event wrapper
    if isinstance(data, dict) and "data" in data and isinstance(data["data"], dict):
        payload = data["data"]
        event = data.get("type") or ""
    else:
        payload = data if isinstance(data, dict) else {}
        event = ""
    email = payload.get("from") or payload.get("email")
    if isinstance(email, dict):
        email = email.get("address") or email.get("email")
    content = payload.get("text") or payload.get("html") or payload.get("body") or ""
    if content and email:
        record_inbound_reply(
            db,
            email=str(email),
            content=str(content)[:5000],
            channel="email",
            external_id=payload.get("email_id") or payload.get("id"),
        )
    return JSONResponse({"ok": True, "event": event})



# ===================== DATA API =====================

def _business_from_api_key(db: Session, request: Request) -> Optional[Business]:
    key = request.headers.get("X-API-Key") or request.query_params.get("api_key")
    if not key or len(key) < 16:
        return None
    for b in db.query(Business).filter(Business.is_active == True).all():
        s = b.settings if isinstance(b.settings, dict) else {}
        stored = decrypt_value(s.get("api_key"))
        if stored and secrets.compare_digest(str(stored), str(key)):
            return b
    return None


@app.post("/api/customers/upsert")
async def api_upsert_customer(request: Request, db: Session = Depends(get_db)):
    business = _business_from_api_key(db, request)
    if not business:
        raise HTTPException(401, "Invalid or missing X-API-Key")
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(400, "JSON body required")
    if not isinstance(data, dict):
        raise HTTPException(400, "Object required")
    customer, created = upsert_customer(db, business.id, data)
    return {"ok": True, "created": created, "customer": {
        "id": customer.id, "first_name": customer.first_name, "last_name": customer.last_name,
        "email": customer.email, "phone": customer.phone, "status": customer.status,
        "last_visit": customer.last_visit.isoformat() if customer.last_visit else None,
        "total_visits": customer.total_visits, "lifetime_value": customer.lifetime_value,
    }}


@app.post("/api/visits")
async def api_record_visit(request: Request, db: Session = Depends(get_db)):
    business = _business_from_api_key(db, request)
    if not business:
        raise HTTPException(401, "Invalid or missing X-API-Key")
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(400, "JSON body required")
    from app.data_sync import parse_date
    c = record_visit(
        db, business.id,
        email=data.get("email"), phone=data.get("phone"),
        external_id=str(data["external_id"]) if data.get("external_id") is not None else None,
        visited_at=parse_date(data.get("visited_at")),
        add_ltv=float(data.get("add_ltv") or 0),
    )
    if not c:
        raise HTTPException(404, "Customer not found")
    return {"ok": True, "customer_id": c.id, "status": c.status,
            "last_visit": c.last_visit.isoformat() if c.last_visit else None, "total_visits": c.total_visits}


@app.post("/api/customers/import")
async def api_import_customers(request: Request, db: Session = Depends(get_db)):
    business = _business_from_api_key(db, request)
    if not business:
        raise HTTPException(401, "Invalid or missing X-API-Key")
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "JSON body required")
    rows = payload if isinstance(payload, list) else payload.get("customers") or []
    if len(rows) > 5000:
        raise HTTPException(400, "Max 5000 rows")
    stats = import_csv_rows(db, business.id, rows)
    return {"ok": True, **stats}


# ===================== ADMIN =====================

@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(request: Request, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    businesses = db.query(Business).all()
    for b in businesses:
        b._customer_count = db.query(Customer).filter(Customer.business_id == b.id).count()
        b._msg_count = db.query(MessageLog).join(Customer).filter(Customer.business_id == b.id).count()
    total_customers = db.query(Customer).count()
    total_users = db.query(User).filter(User.role == "client").count()
    total_messages = db.query(MessageLog).count()
    active_enrollments = db.query(Enrollment).filter(Enrollment.status == EnrollmentStatus.ACTIVE.value).count()
    recent_activity = (
        db.query(MessageLog).options(joinedload(MessageLog.customer))
        .order_by(MessageLog.created_at.desc()).limit(12).all()
    )
    return templates.TemplateResponse("admin/dashboard.html", {
        "request": request, "user": user, "businesses": businesses,
        "total_customers": total_customers, "total_users": total_users,
        "total_messages": total_messages, "active_enrollments": active_enrollments,
        "recent_activity": recent_activity, "page": "dashboard",
    })


@app.get("/admin/businesses", response_class=HTMLResponse)
async def admin_businesses(request: Request, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    businesses = db.query(Business).order_by(Business.created_at.desc()).all()
    for b in businesses:
        b._customer_count = db.query(Customer).filter(Customer.business_id == b.id).count()
        b._user_count = db.query(User).filter(User.business_id == b.id).count()
        b._active_enroll = (
            db.query(Enrollment).join(Customer)
            .filter(Customer.business_id == b.id, Enrollment.status == EnrollmentStatus.ACTIVE.value).count()
        )
    return templates.TemplateResponse("admin/businesses.html", {
        "request": request, "user": user, "businesses": businesses, "page": "businesses",
        "new_owner_email": request.query_params.get("owner_email"),
        "new_owner_temp_password": request.query_params.get("temp_password"),
    })


@app.post("/admin/businesses/create")
async def admin_create_business(
    request: Request,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
    name: str = Form(...),
    industry: str = Form("gym"),
    timezone: str = Form("America/New_York"),
    owner_email: str = Form(...),
    owner_name: str = Form(""),
):
    """
    Onboard a new client business + its owner login. Previously there was no
    way to do this at all — only the two seeded demo businesses existed, and
    a real client had to be inserted by hand via SQL/a script. Generates a
    temporary password shown once on the redirect; the client should change
    it after first login (there's no self-serve password change yet — see
    audit notes).
    """
    name = (name or "").strip()
    owner_email = (owner_email or "").strip().lower()
    if not name or not owner_email or not EMAIL_RE.match(owner_email):
        raise HTTPException(400, "Business name and a valid owner email are required")
    if db.query(User).filter(User.email == owner_email).first():
        raise HTTPException(400, "A user with that email already exists")

    business = Business(name=name, industry=industry or "gym", timezone=timezone or "America/New_York", settings={})
    db.add(business)
    db.commit()
    db.refresh(business)

    temp_password = secrets.token_urlsafe(9)
    owner = User(
        email=owner_email,
        hashed_password=get_password_hash(temp_password),
        full_name=(owner_name or "").strip() or None,
        role="client",
        business_id=business.id,
        is_active=True,
    )
    db.add(owner)
    db.commit()

    return RedirectResponse(
        f"/admin/businesses?created=1&owner_email={owner_email}&temp_password={temp_password}",
        status_code=302,
    )


@app.get("/admin/businesses/{biz_id}", response_class=HTMLResponse)
async def admin_business_detail(biz_id: int, request: Request, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    business = db.query(Business).filter(Business.id == biz_id).first()
    if not business:
        raise HTTPException(404)
    stats = get_dashboard_stats(db, business.id)
    users = db.query(User).filter(User.business_id == business.id).all()
    sequences = db.query(Sequence).filter(Sequence.business_id == business.id).all()
    recent = (
        db.query(Customer).filter(Customer.business_id == business.id)
        .order_by(Customer.updated_at.desc()).limit(15).all()
    )
    integ = integration_status(business)
    return templates.TemplateResponse("admin/business_detail.html", {
        "request": request, "user": user, "business": business, "stats": stats,
        "users": users, "sequences": sequences, "recent_customers": recent,
        "integrations": integ, "page": "businesses",
    })


@app.post("/admin/businesses/{biz_id}/toggle")
async def admin_toggle_business(biz_id: int, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    b = db.query(Business).filter(Business.id == biz_id).first()
    if b:
        b.is_active = not b.is_active
        db.commit()
    return RedirectResponse(f"/admin/businesses/{biz_id}", status_code=302)


@app.post("/admin/businesses/{biz_id}/integrations")
async def admin_save_integrations(
    biz_id: int,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
    twilio_account_sid: str = Form(""),
    twilio_auth_token: str = Form(""),
    twilio_from_number: str = Form(""),
    twilio_whatsapp_from: str = Form(""),
    resend_api_key: str = Form(""),
    resend_from_email: str = Form(""),
    n8n_whatsapp_webhook: str = Form(""),
    meta_whatsapp_token: str = Form(""),
    meta_whatsapp_phone_id: str = Form(""),
):
    """Platform-only: set messaging provider keys for a client business."""
    business = db.query(Business).filter(Business.id == biz_id).first()
    if not business:
        raise HTTPException(404)
    s = dict(business.settings) if isinstance(business.settings, dict) else {}
    integ = dict(s.get("integrations") or {}) if isinstance(s.get("integrations"), dict) else {}
    for k, v in {
        "twilio_account_sid": twilio_account_sid,
        "twilio_auth_token": twilio_auth_token,
        "twilio_from_number": twilio_from_number,
        "twilio_whatsapp_from": twilio_whatsapp_from,
        "resend_api_key": resend_api_key,
        "resend_from_email": resend_from_email,
        "n8n_whatsapp_webhook": n8n_whatsapp_webhook,
        "meta_whatsapp_token": meta_whatsapp_token,
        "meta_whatsapp_phone_id": meta_whatsapp_phone_id,
    }.items():
        v = (v or "").strip()
        if v:
            # SECURITY: secrets (auth tokens/API keys) are encrypted at rest —
            # previously stored as plaintext JSON in business.settings, so a
            # DB leak would expose every client's live provider credentials.
            integ[k] = encrypt_value(v) if k in SECRET_SETTING_KEYS else v
    s["integrations"] = integ
    business.settings = s
    flag_modified(business, "settings")
    db.commit()
    return RedirectResponse(f"/admin/businesses/{biz_id}?integrations_saved=1", status_code=302)

@app.post("/admin/businesses/{biz_id}/ai")
async def admin_save_ai_modes(
    biz_id: int,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
    sequences_mode: str = Form("template"),
    auto_reply_mode: str = Form("rules"),
    ai_api_key: str = Form(""),
    ai_base_url: str = Form(""),
    ai_model: str = Form(""),
):
    business = db.query(Business).filter(Business.id == biz_id).first()
    if not business:
        raise HTTPException(404)
    s = dict(business.settings) if isinstance(business.settings, dict) else {}
    ai = dict(s.get("ai") or {}) if isinstance(s.get("ai"), dict) else {}
    if sequences_mode in ("template", "ai", "both"):
        ai["sequences_mode"] = sequences_mode
    if auto_reply_mode in ("rules", "ai", "both"):
        ai["auto_reply_mode"] = auto_reply_mode
    if (ai_api_key or "").strip():
        ai["api_key"] = encrypt_value(ai_api_key.strip())
    if (ai_base_url or "").strip():
        ai["base_url"] = ai_base_url.strip()
    if (ai_model or "").strip():
        ai["model"] = ai_model.strip()
    s["ai"] = ai
    business.settings = s
    flag_modified(business, "settings")
    db.commit()
    return RedirectResponse(f"/admin/businesses/{biz_id}?ai_saved=1", status_code=302)


@app.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    users = db.query(User).options(joinedload(User.business)).order_by(User.created_at.desc()).all()
    return templates.TemplateResponse("admin/users.html", {
        "request": request, "user": user, "users": users, "page": "users",
    })


def _run_bot_for_all_businesses(db: Session) -> list:
    businesses = db.query(Business).filter(Business.is_active == True).all()
    results = []
    for b in businesses:
        results.append({
            "business": b.name,
            "status_changed": update_customer_statuses(db, b.id),
            "enrolled": auto_enroll_by_rules(db, b.id),
            "stats": process_pending_steps(db, b.id),
        })
    return results


@app.post("/admin/run-global-bot")
async def admin_run_bot(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    results = _run_bot_for_all_businesses(db)
    return JSONResponse({"ok": True, "results": results})


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "FollowUp CRM + Reactivation", "version": "3.0.0"}
