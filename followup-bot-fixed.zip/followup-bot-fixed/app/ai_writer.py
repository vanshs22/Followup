"""
AI message writer for sequences and auto-replies.
Uses OpenAI-compatible API (OpenAI, xAI Grok, etc.) when AI_API_KEY is set.
Falls back to smart local templates when no key / API fails.
"""
from __future__ import annotations

import os
import json
import logging
from typing import Optional, Dict, Any, List

import httpx

from app.crypto import decrypt_value

logger = logging.getLogger("followup.ai")

AI_API_KEY = os.environ.get("AI_API_KEY") or os.environ.get("OPENAI_API_KEY") or os.environ.get("XAI_API_KEY") or ""
AI_BASE_URL = os.environ.get("AI_BASE_URL", "https://api.openai.com/v1")
AI_MODEL = os.environ.get("AI_MODEL", "gpt-4o-mini")


def _biz_ai_config(business) -> Dict[str, Any]:
    s = {}
    if business and isinstance(getattr(business, "settings", None), dict):
        s = business.settings or {}
    ai = s.get("ai") if isinstance(s.get("ai"), dict) else {}
    # Platform can also store key per-business under settings.ai (encrypted at rest)
    return {
        "api_key": decrypt_value(ai.get("api_key")) or AI_API_KEY,
        "base_url": (ai.get("base_url") or AI_BASE_URL).rstrip("/"),
        "model": ai.get("model") or AI_MODEL,
        "sequences_mode": ai.get("sequences_mode") or s.get("sequences_mode") or "template",  # template | ai | both
        "auto_reply_mode": ai.get("auto_reply_mode") or s.get("auto_reply_mode") or "rules",  # rules | ai | both
    }


def ai_enabled_for_sequences(business) -> bool:
    mode = _biz_ai_config(business)["sequences_mode"]
    return mode in ("ai", "both")


def ai_enabled_for_auto_reply(business) -> bool:
    mode = _biz_ai_config(business)["auto_reply_mode"]
    return mode in ("ai", "both")


def rules_enabled_for_auto_reply(business) -> bool:
    mode = _biz_ai_config(business)["auto_reply_mode"]
    return mode in ("rules", "both", None, "")


def _chat(system: str, user: str, cfg: dict) -> Optional[str]:
    key = cfg.get("api_key") or ""
    if not key:
        return None
    url = f"{cfg['base_url']}/chat/completions"
    try:
        with httpx.Client(timeout=45.0) as client:
            r = client.post(
                url,
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={
                    "model": cfg.get("model") or "gpt-4o-mini",
                    "temperature": 0.7,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                },
            )
        if r.status_code >= 400:
            logger.warning("AI API error %s: %s", r.status_code, r.text[:300])
            return None
        data = r.json()
        return (data["choices"][0]["message"]["content"] or "").strip()
    except Exception:
        logger.exception("AI chat failed")
        return None


def _fallback_sequence_message(
    *,
    business_name: str,
    industry: str,
    sequence_type: str,
    step_order: int,
    channel: str,
    total_steps: int,
) -> str:
    industry = (industry or "business").replace("_", " ")
    st = (sequence_type or "follow_up").replace("_", " ")
    name = business_name or "us"
    if step_order <= 1:
        return (
            f"Hi {{{{first_name}}}}, thanks for being part of {name}! "
            f"Just checking in after your recent visit. How are you feeling? Reply anytime — we are here to help."
        )
    if step_order == 2:
        return (
            f"Hi {{{{first_name}}}}, it is {name}. Ready for your next {industry} session? "
            f"Book a time that works for you — we would love to see you again."
        )
    if "reactivation" in st or "win" in st:
        return (
            f"{{{{first_name}}}}, we miss you at {name}. Come back this week and enjoy a special welcome-back offer. "
            f"Reply YES and we will help you schedule."
        )
    return (
        f"Hi {{{{first_name}}}}, a quick note from {name}. "
        f"Step {step_order} of your {st} — we are still thinking of you. Reply if you need anything."
    )


def generate_sequence_step_message(
    business,
    *,
    sequence_name: str,
    sequence_type: str,
    step_order: int,
    channel: str,
    delay_days: int = 0,
    total_steps: int = 3,
    extra_context: str = "",
) -> Dict[str, str]:
    """Returns {subject, message_template}."""
    cfg = _biz_ai_config(business)
    bname = getattr(business, "name", None) or "our business"
    industry = getattr(business, "industry", None) or "local business"
    system = (
        "You write short, friendly customer follow-up messages for local businesses "
        "(gyms, med spas, salons, home services). "
        "Use merge tags exactly when needed: {{first_name}}, {{business_name}}, {{ltv}}. "
        "Keep SMS/WhatsApp under 320 characters. Email can be 2-4 short sentences. "
        "No markdown. No hashtags spam. Output JSON only: "
        '{"subject": "... or empty for sms", "message_template": "..."}'
    )
    user = (
        f"Business: {bname} ({industry})\n"
        f"Sequence: {sequence_name} ({sequence_type})\n"
        f"Step {step_order} of {total_steps}, channel={channel}, delay_days={delay_days}\n"
        f"Extra: {extra_context or 'none'}\n"
        f"Write the message for this step."
    )
    raw = _chat(system, user, cfg)
    if raw:
        try:
            # extract JSON object
            start, end = raw.find("{"), raw.rfind("}")
            if start >= 0 and end > start:
                data = json.loads(raw[start : end + 1])
                msg = (data.get("message_template") or data.get("message") or "").strip()
                subj = (data.get("subject") or "").strip()
                if msg:
                    return {"subject": subj if channel == "email" else "", "message_template": msg}
        except Exception:
            # use raw text as message
            text = raw.strip().strip("`")
            if text:
                return {"subject": f"A note from {bname}" if channel == "email" else "", "message_template": text}

    fb = _fallback_sequence_message(
        business_name=bname, industry=industry, sequence_type=sequence_type,
        step_order=step_order, channel=channel, total_steps=total_steps,
    )
    return {
        "subject": f"From {bname}" if channel == "email" else "",
        "message_template": fb,
    }


def generate_auto_reply(
    business,
    *,
    inbound_text: str,
    channel: str,
    customer_first_name: str = "there",
) -> str:
    cfg = _biz_ai_config(business)
    bname = getattr(business, "name", None) or "us"
    industry = getattr(business, "industry", None) or "business"
    system = (
        "You are a helpful front-desk assistant for a local business. "
        "Write one short reply to the customer's message. "
        "Be warm, clear, and actionable. Under 280 chars for SMS/WhatsApp. "
        "If they want to book, invite a day/time or say the team will help. "
        "If pricing, give a helpful next step without inventing exact prices unless obvious. "
        "Do not claim to be human if unsure. Plain text only."
    )
    user = (
        f"Business: {bname} ({industry})\n"
        f"Channel: {channel}\n"
        f"Customer first name: {customer_first_name}\n"
        f"Customer said: {inbound_text}\n"
        f"Write the reply."
    )
    raw = _chat(system, user, cfg)
    if raw:
        return raw.strip().strip("`")

    # fallback
    low = (inbound_text or "").lower()
    if any(w in low for w in ("book", "yes", "schedule", "appointment")):
        return f"Great {customer_first_name}! Tell us a day/time that works and we will get you scheduled at {bname}."
    if any(w in low for w in ("price", "cost", "how much")):
        return f"Happy to help with pricing, {customer_first_name}. Our team will follow up shortly from {bname}."
    return f"Thanks for your message, {customer_first_name}! We got it and will help you shortly — {bname}."


def generate_sequence_plan(
    business,
    *,
    sequence_name: str,
    sequence_type: str,
    channels: Optional[List[str]] = None,
    num_steps: int = 3,
) -> List[Dict[str, Any]]:
    """Generate a full multi-step plan (order, delay, channel, subject, message)."""
    channels = channels or ["sms", "sms", "email"]
    steps = []
    for i in range(1, max(1, min(num_steps, 6)) + 1):
        ch = channels[(i - 1) % len(channels)]
        delay = 0 if i == 1 else (2 if i == 2 else 5 * (i - 2) + 3)
        content = generate_sequence_step_message(
            business,
            sequence_name=sequence_name,
            sequence_type=sequence_type,
            step_order=i,
            channel=ch,
            delay_days=delay,
            total_steps=num_steps,
        )
        steps.append({
            "order": i,
            "delay_days": delay,
            "delay_hours": 0,
            "channel": ch,
            "subject": content.get("subject") or None,
            "message_template": content["message_template"],
        })
    return steps
