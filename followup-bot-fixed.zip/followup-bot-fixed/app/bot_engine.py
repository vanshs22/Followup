"""
Follow-up + Reactivation Bot Engine with real providers (Twilio / Resend / WhatsApp).
"""
from datetime import datetime, timedelta
from sqlalchemy.orm import Session, joinedload
from app.models import (
    Customer, Sequence, SequenceStep, Enrollment, MessageLog, Business,
    CustomerStatus, EnrollmentStatus, MessageStatus, AutoReplyRule,
)
from app.integrations import send_message
from app.database import DB_BACKEND
from app import ai_writer
from typing import Optional
import json


def render_template(template: str, customer: Customer, business_name: str = "us") -> str:
    first = customer.first_name or "there"
    last = customer.last_name or ""
    full = f"{first} {last}".strip()
    return (
        (template or "")
        .replace("{{first_name}}", first)
        .replace("{{last_name}}", last)
        .replace("{{full_name}}", full)
        .replace("{{email}}", customer.email or "")
        .replace("{{phone}}", customer.phone or "")
        .replace("{{business_name}}", business_name)
        .replace("{{total_visits}}", str(customer.total_visits or 0))
        .replace("{{ltv}}", f"{customer.lifetime_value or 0:.0f}")
    )


def calculate_customer_status(customer: Customer) -> str:
    if not customer.last_visit:
        return CustomerStatus.NEW.value
    days = (datetime.utcnow() - customer.last_visit).days
    if days <= 14:
        return CustomerStatus.ACTIVE.value
    if days <= 30:
        return CustomerStatus.AT_RISK.value
    if days <= 90:
        return CustomerStatus.DORMANT.value
    return CustomerStatus.CHURNED.value


def update_customer_statuses(db: Session, business_id: int) -> int:
    customers = db.query(Customer).filter(Customer.business_id == business_id).all()
    changed = 0
    for c in customers:
        new_status = calculate_customer_status(c)
        if c.status != new_status:
            c.status = new_status
            c.updated_at = datetime.utcnow()
            changed += 1
    db.commit()
    return changed


def _customer_has_tag(customer: Customer, tag: str) -> bool:
    tags = customer.tags or []
    if isinstance(tags, str):
        try:
            tags = json.loads(tags)
        except Exception:
            tags = [tags]
    return tag.lower() in [str(t).lower() for t in tags]


def enroll_customer(
    db: Session,
    customer: Customer,
    sequence: Sequence,
    force: bool = False,
) -> Optional[Enrollment]:
    if customer.opted_out:
        return None
    existing = (
        db.query(Enrollment)
        .filter(
            Enrollment.customer_id == customer.id,
            Enrollment.sequence_id == sequence.id,
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
        )
        .first()
    )
    if existing and not force:
        return existing
    if existing and force:
        # BUGFIX: force=True previously skipped this entirely, so re-enrolling
        # a customer already active in this exact sequence created a second,
        # parallel Enrollment row. process_pending_steps() would then process
        # both, and the customer received every step of that sequence twice
        # on independent schedules. Cancel the prior run before starting a
        # fresh one instead of stacking a duplicate.
        existing.status = EnrollmentStatus.CANCELLED.value
        existing.next_action_at = None

    # Also cancel any other active enrollment of the same sequence *type*
    # (e.g. don't run two different reactivation sequences at once). This
    # now always runs before creating a new enrollment, not just when
    # force=False, so the force-enroll path gets the same protection.
    active = (
        db.query(Enrollment)
        .options(joinedload(Enrollment.sequence))
        .filter(
            Enrollment.customer_id == customer.id,
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
        )
        .all()
    )
    for e in active:
        if e.sequence and e.sequence.sequence_type == sequence.sequence_type:
            e.status = EnrollmentStatus.CANCELLED.value
            e.next_action_at = None

    first_step = (
        db.query(SequenceStep)
        .filter(SequenceStep.sequence_id == sequence.id, SequenceStep.is_active == True)
        .order_by(SequenceStep.order)
        .first()
    )
    next_action = datetime.utcnow()
    if first_step:
        next_action += timedelta(days=first_step.delay_days or 0, hours=first_step.delay_hours or 0)

    enrollment = Enrollment(
        customer_id=customer.id,
        sequence_id=sequence.id,
        status=EnrollmentStatus.ACTIVE.value,
        current_step=0,
        next_action_at=next_action,
    )
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return enrollment


def auto_enroll_by_rules(db: Session, business_id: int) -> int:
    sequences = (
        db.query(Sequence)
        .filter(Sequence.business_id == business_id, Sequence.is_active == True)
        .all()
    )
    enrolled_count = 0
    for seq in sequences:
        rules = seq.trigger_rules or {}
        if not rules:
            continue
        query = db.query(Customer).filter(
            Customer.business_id == business_id,
            Customer.opted_out == False,
        )
        if "status" in rules:
            query = query.filter(Customer.status == rules["status"])
        if "days_since_last_visit" in rules:
            cutoff = datetime.utcnow() - timedelta(days=int(rules["days_since_last_visit"]))
            query = query.filter(Customer.last_visit.isnot(None), Customer.last_visit <= cutoff)
        if "min_ltv" in rules:
            query = query.filter(Customer.lifetime_value >= float(rules["min_ltv"]))
        candidates = query.all()
        tag = rules.get("has_tag")
        if tag:
            candidates = [c for c in candidates if _customer_has_tag(c, tag)]
        for customer in candidates:
            existing = (
                db.query(Enrollment)
                .filter(
                    Enrollment.customer_id == customer.id,
                    Enrollment.sequence_id == seq.id,
                    Enrollment.status == EnrollmentStatus.ACTIVE.value,
                )
                .first()
            )
            if existing:
                continue
            enroll_customer(db, customer, seq)
            enrolled_count += 1
    return enrolled_count


def process_pending_steps(db: Session, business_id: Optional[int] = None) -> dict:
    now = datetime.utcnow()
    query = (
        db.query(Enrollment)
        .options(
            joinedload(Enrollment.customer).joinedload(Customer.business),
            joinedload(Enrollment.sequence),
        )
        .filter(
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
            Enrollment.next_action_at.isnot(None),
            Enrollment.next_action_at <= now,
        )
    )
    if business_id:
        query = query.join(Customer).filter(Customer.business_id == business_id)
    if DB_BACKEND == "supabase":
        # BUGFIX: two overlapping bot runs (e.g. a client's "Run Bot Now" and
        # the platform's "Run global bot" firing close together, or a future
        # cron overlapping a manual click) could previously both fetch the
        # same due enrollment and each send its step before either commit
        # landed, double-messaging the customer. SKIP LOCKED lets each
        # concurrent run claim a disjoint set of rows instead of colliding.
        # SQLite (local/demo mode) doesn't support FOR UPDATE, so this only
        # applies on the Postgres/Supabase backend.
        query = query.with_for_update(skip_locked=True)
    due = query.all()
    stats = {"processed": 0, "sent": 0, "completed": 0, "failed": 0, "simulated": 0}
    for enrollment in due:
        result = process_enrollment_step(db, enrollment)
        stats["processed"] += 1
        if result in stats:
            stats[result] += 1
        elif result == "sent":
            stats["sent"] += 1
    return stats


def process_enrollment_step(db: Session, enrollment: Enrollment) -> str:
    sequence = enrollment.sequence
    if not sequence:
        enrollment.status = EnrollmentStatus.FAILED.value
        db.commit()
        return "failed"

    customer = enrollment.customer
    if not customer or customer.opted_out:
        enrollment.status = EnrollmentStatus.CANCELLED.value
        enrollment.next_action_at = None
        db.commit()
        return "failed"

    steps = (
        db.query(SequenceStep)
        .filter(SequenceStep.sequence_id == sequence.id, SequenceStep.is_active == True)
        .order_by(SequenceStep.order)
        .all()
    )
    if not steps or enrollment.current_step >= len(steps):
        enrollment.status = EnrollmentStatus.COMPLETED.value
        enrollment.completed_at = datetime.utcnow()
        enrollment.next_action_at = None
        db.commit()
        return "completed"

    step = steps[enrollment.current_step]
    business = customer.business
    business_name = business.name if business else "us"
    if not business and customer.business_id:
        business = db.query(Business).filter(Business.id == customer.business_id).first()
        if business:
            business_name = business.name

    content = render_template(step.message_template, customer, business_name)
    subject = render_template(step.subject, customer, business_name) if step.subject else None

    # Optional AI rewrite at send-time when sequences_mode is ai/both
    if business and ai_writer.ai_enabled_for_sequences(business):
        mode = ai_writer._biz_ai_config(business)["sequences_mode"]
        if mode == "ai" or (mode == "both" and not (step.message_template or "").strip()):
            gen = ai_writer.generate_sequence_step_message(
                business,
                sequence_name=sequence.name if sequence else "Follow-up",
                sequence_type=sequence.sequence_type if sequence else "follow_up",
                step_order=enrollment.current_step + 1,
                channel=step.channel,
                delay_days=step.delay_days or 0,
                total_steps=len(steps),
            )
            content = render_template(gen["message_template"], customer, business_name)
            if gen.get("subject"):
                subject = render_template(gen["subject"], customer, business_name)

    to = customer.phone if step.channel in ("sms", "whatsapp", "call") else customer.email
    success, detail, external_id = send_message(
        step.channel,
        to or "",
        content,
        subject=subject,
        business=business,
        customer=customer,
        metadata={
            "enrollment_id": enrollment.id,
            "customer_id": customer.id,
            "sequence_id": sequence.id,
            "step": enrollment.current_step,
        },
    )

    is_sim = detail.startswith("simulated")
    status = MessageStatus.SIMULATED.value if is_sim and success else (
        MessageStatus.SENT.value if success else MessageStatus.FAILED.value
    )

    log = MessageLog(
        customer_id=customer.id,
        enrollment_id=enrollment.id,
        channel=step.channel,
        direction="outbound",
        subject=subject,
        content=content,
        status=status,
        provider_detail=detail,
        external_id=external_id,
        sent_at=datetime.utcnow() if success else None,
        error_message=None if success else detail,
    )
    db.add(log)

    if success:
        enrollment.current_step += 1
        if enrollment.current_step < len(steps):
            next_step = steps[enrollment.current_step]
            enrollment.next_action_at = datetime.utcnow() + timedelta(
                days=next_step.delay_days or 0, hours=next_step.delay_hours or 0
            )
        else:
            enrollment.status = EnrollmentStatus.COMPLETED.value
            enrollment.completed_at = datetime.utcnow()
            enrollment.next_action_at = None
        db.commit()
        return "simulated" if is_sim else "sent"
    else:
        meta = enrollment.metadata_ or {}
        retries = int(meta.get("fail_retries", 0)) + 1
        meta["fail_retries"] = retries
        enrollment.metadata_ = meta
        if retries >= 3:
            enrollment.status = EnrollmentStatus.FAILED.value
            enrollment.next_action_at = None
        else:
            enrollment.next_action_at = datetime.utcnow() + timedelta(hours=1)
        db.commit()
        return "failed"


def record_inbound_reply(
    db: Session,
    *,
    phone: Optional[str] = None,
    email: Optional[str] = None,
    content: str,
    channel: str = "sms",
    external_id: Optional[str] = None,
    business_id: Optional[int] = None,
) -> Optional[MessageLog]:
    """Store inbound reply, apply wins/opt-out, run auto-reply rules."""
    q = db.query(Customer)
    if business_id:
        q = q.filter(Customer.business_id == business_id)
    customer = None
    if phone:
        digits = "".join(c for c in phone if c.isdigit())
        for c in q.all():
            if c.phone and "".join(x for x in c.phone if x.isdigit()).endswith(digits[-10:]):
                customer = c
                break
    if not customer and email:
        customer = q.filter(Customer.email == (email or "").strip().lower()).first()
    if not customer:
        return None

    log = MessageLog(
        customer_id=customer.id,
        channel=channel,
        direction="inbound",
        content=content,
        status=MessageStatus.REPLIED.value,
        provider_detail="inbound",
        external_id=external_id,
        sent_at=datetime.utcnow(),
        replied_at=datetime.utcnow(),
    )
    db.add(log)
    customer.last_reply_at = datetime.utcnow()
    customer.updated_at = datetime.utcnow()

    text_l = (content or "").lower()
    positive = any(
        w in text_l
        for w in ("yes", "book", "interested", "sure", "ok", "coming", "schedule", "yeah", "yep")
    )
    if positive:
        active = (
            db.query(Enrollment)
            .filter(
                Enrollment.customer_id == customer.id,
                Enrollment.status == EnrollmentStatus.ACTIVE.value,
            )
            .all()
        )
        for e in active:
            e.status = EnrollmentStatus.WON.value
            e.won_at = datetime.utcnow()
            e.win_note = "Positive reply"
            e.completed_at = datetime.utcnow()
            e.next_action_at = None
        customer.win_count = (customer.win_count or 0) + 1
        if customer.status in (
            CustomerStatus.DORMANT.value,
            CustomerStatus.CHURNED.value,
            CustomerStatus.AT_RISK.value,
        ):
            customer.status = CustomerStatus.ACTIVE.value
            customer.last_visit = datetime.utcnow()

    if any(w in text_l for w in ("stop", "unsubscribe", "opt out", "optout")):
        customer.opted_out = True
        active = (
            db.query(Enrollment)
            .filter(
                Enrollment.customer_id == customer.id,
                Enrollment.status == EnrollmentStatus.ACTIVE.value,
            )
            .all()
        )
        for e in active:
            e.status = EnrollmentStatus.CANCELLED.value
            e.next_action_at = None
        db.commit()
        db.refresh(log)
        return log

    db.commit()
    db.refresh(log)

    # Auto-reply rules (after commit of inbound)
    try:
        _apply_auto_reply(db, customer, content, channel)
    except Exception:
        pass
    return log


def _apply_auto_reply(db: Session, customer: Customer, inbound_text: str, channel: str):
    if customer.opted_out:
        return
    business = customer.business or db.query(Business).filter(Business.id == customer.business_id).first()
    replied = False

    # 1) Keyword rules (if enabled)
    if ai_writer.rules_enabled_for_auto_reply(business):
        rules = (
            db.query(AutoReplyRule)
            .filter(AutoReplyRule.business_id == customer.business_id, AutoReplyRule.is_active == True)
            .order_by(AutoReplyRule.priority.asc())
            .all()
        )
        text_l = (inbound_text or "").lower()
        for rule in rules:
            if rule.channel not in ("any", None, "") and rule.channel != channel:
                continue
            kws = rule.keywords or []
            if isinstance(kws, str):
                kws = [k.strip() for k in kws.split(",") if k.strip()]
            if kws and not any(str(k).lower() in text_l for k in kws):
                continue
            reply_ch = rule.reply_channel if rule.reply_channel != "same" else channel
            body = render_template(rule.reply_template, customer, business.name if business else "us")
            to = customer.phone if reply_ch in ("sms", "whatsapp", "call") else customer.email
            success, detail, ext = send_message(
                reply_ch, to or "", body, subject="Re: your message",
                business=business, customer=customer,
                metadata={"auto_reply_rule_id": rule.id},
            )
            is_sim = (detail or "").startswith("simulated")
            db.add(MessageLog(
                customer_id=customer.id,
                channel=reply_ch,
                direction="outbound",
                content=body,
                status=MessageStatus.SIMULATED.value if is_sim and success else (
                    MessageStatus.SENT.value if success else MessageStatus.FAILED.value
                ),
                provider_detail=f"auto_reply_rule:{detail}",
                external_id=ext,
                sent_at=datetime.utcnow() if success else None,
                error_message=None if success else detail,
            ))
            db.commit()
            replied = True
            break

    # 2) AI auto-reply (if enabled and rules did not already reply, or mode is ai-only)
    if ai_writer.ai_enabled_for_auto_reply(business):
        mode = ai_writer._biz_ai_config(business)["auto_reply_mode"]
        if mode == "ai" or (mode == "both" and not replied):
            body = ai_writer.generate_auto_reply(
                business,
                inbound_text=inbound_text,
                channel=channel,
                customer_first_name=customer.first_name or "there",
            )
            reply_ch = channel if channel in ("sms", "email", "whatsapp") else "sms"
            to = customer.phone if reply_ch in ("sms", "whatsapp") else customer.email
            success, detail, ext = send_message(
                reply_ch, to or "", body, subject="Re: your message",
                business=business, customer=customer,
                metadata={"auto_reply": "ai"},
            )
            is_sim = (detail or "").startswith("simulated")
            db.add(MessageLog(
                customer_id=customer.id,
                channel=reply_ch,
                direction="outbound",
                content=body,
                status=MessageStatus.SIMULATED.value if is_sim and success else (
                    MessageStatus.SENT.value if success else MessageStatus.FAILED.value
                ),
                provider_detail=f"auto_reply_ai:{detail}",
                external_id=ext,
                sent_at=datetime.utcnow() if success else None,
                error_message=None if success else detail,
            ))
            db.commit()



def send_one_off(
    db: Session,
    customer: Customer,
    channel: str,
    content: str,
    subject: Optional[str] = None,
) -> MessageLog:
    """Manual one-click message from CRM UI."""
    business = customer.business or db.query(Business).filter(Business.id == customer.business_id).first()
    body = render_template(content, customer, business.name if business else "us")
    subj = render_template(subject, customer, business.name if business else "us") if subject else None
    to = customer.phone if channel in ("sms", "whatsapp", "call") else customer.email
    success, detail, ext = send_message(
        channel, to or "", body, subject=subj, business=business, customer=customer,
        metadata={"manual": True},
    )
    is_sim = (detail or "").startswith("simulated")
    log = MessageLog(
        customer_id=customer.id,
        channel=channel,
        direction="outbound",
        subject=subj,
        content=body,
        status=MessageStatus.SIMULATED.value if is_sim and success else (
            MessageStatus.SENT.value if success else MessageStatus.FAILED.value
        ),
        provider_detail=detail,
        external_id=ext,
        sent_at=datetime.utcnow() if success else None,
        error_message=None if success else detail,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log



def get_dashboard_stats(db: Session, business_id: int) -> dict:
    customers = db.query(Customer).filter(Customer.business_id == business_id).all()
    total = len(customers)
    by_status = {s.value: 0 for s in CustomerStatus}
    for c in customers:
        by_status[c.status] = by_status.get(c.status, 0) + 1

    active_enrollments = (
        db.query(Enrollment)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            Enrollment.status == EnrollmentStatus.ACTIVE.value,
        )
        .count()
    )
    month_start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    completed_this_month = (
        db.query(Enrollment)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            Enrollment.status.in_([EnrollmentStatus.COMPLETED.value, EnrollmentStatus.WON.value]),
            Enrollment.completed_at >= month_start,
        )
        .count()
    )
    wins_this_month = (
        db.query(Enrollment)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            Enrollment.status == EnrollmentStatus.WON.value,
            Enrollment.won_at >= month_start,
        )
        .count()
    )
    messages_this_month = (
        db.query(MessageLog)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            MessageLog.direction == "outbound",
            MessageLog.sent_at >= month_start,
        )
        .count()
    )
    replies_this_month = (
        db.query(MessageLog)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            MessageLog.direction == "inbound",
            MessageLog.created_at >= month_start,
        )
        .count()
    )
    failed_this_month = (
        db.query(MessageLog)
        .join(Customer)
        .filter(
            Customer.business_id == business_id,
            MessageLog.status == MessageStatus.FAILED.value,
            MessageLog.created_at >= month_start,
        )
        .count()
    )
    opted_out = sum(1 for c in customers if c.opted_out)

    return {
        "total_customers": total,
        "by_status": by_status,
        "active_enrollments": active_enrollments,
        "completed_this_month": completed_this_month,
        "wins_this_month": wins_this_month,
        "messages_this_month": messages_this_month,
        "replies_this_month": replies_this_month,
        "failed_this_month": failed_this_month,
        "opted_out": opted_out,
        "reactivated_approx": by_status.get("active", 0),
    }
