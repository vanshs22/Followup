"""
Encrypt-at-rest helpers for provider credentials stored in Business.settings
(Twilio auth token, Resend API key, Meta token, AI API key, client Data API key).

Without this, a Supabase/DB read (leaked backup, over-broad service role, a
support person poking around) exposes every live client's messaging and AI
credentials in plain JSON. Values are encrypted with Fernet (AES-128-CBC +
HMAC) using a key derived from FOLLOWUP_ENCRYPTION_KEY (preferred) or, if
unset, from the app's JWT secret (so at least it's not a fixed default —
but you should set FOLLOWUP_ENCRYPTION_KEY explicitly in production).

Encrypted values are stored with an "enc:" prefix so plaintext values saved
by older versions of this app are still read correctly (graceful migration —
they'll be re-encrypted the next time that field is saved).
"""
from __future__ import annotations

import base64
import hashlib
import os
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken

_ENC_PREFIX = "enc:"


def _derive_key() -> bytes:
    raw = os.environ.get("FOLLOWUP_ENCRYPTION_KEY", "").strip()
    if not raw:
        # Fall back to deriving from the JWT secret so we're not hardcoding a
        # shared default — but this means changing FOLLOWUP_SECRET without
        # migrating will make existing encrypted values unreadable. Setting
        # FOLLOWUP_ENCRYPTION_KEY explicitly (a separate, stable secret) is
        # the correct production setup.
        from app.auth import SECRET_KEY
        raw = SECRET_KEY
    digest = hashlib.sha256(raw.encode("utf-8")).digest()
    return base64.urlsafe_b64encode(digest)


_fernet: Optional[Fernet] = None


def _get_fernet() -> Fernet:
    global _fernet
    if _fernet is None:
        _fernet = Fernet(_derive_key())
    return _fernet


def encrypt_value(plain: str) -> str:
    """Encrypt a secret for storage. Returns the value prefixed with 'enc:'."""
    if not plain:
        return plain
    if plain.startswith(_ENC_PREFIX):
        return plain  # already encrypted, don't double-wrap
    token = _get_fernet().encrypt(plain.encode("utf-8")).decode("utf-8")
    return _ENC_PREFIX + token


def decrypt_value(stored: Optional[str]) -> Optional[str]:
    """
    Decrypt a value previously saved with encrypt_value. If the value doesn't
    have the enc: prefix (older plaintext row, or empty), it's returned as-is
    so existing installs keep working until the field is next saved.
    """
    if not stored:
        return stored
    if not stored.startswith(_ENC_PREFIX):
        return stored
    token = stored[len(_ENC_PREFIX):]
    try:
        return _get_fernet().decrypt(token.encode("utf-8")).decode("utf-8")
    except (InvalidToken, Exception):
        # Wrong/rotated key — don't crash the request, just surface nothing
        # usable so a misconfigured send fails loudly via the provider
        # rather than silently using garbage.
        return None


# Fields that hold live provider/AI credentials and should always be
# encrypted at rest.
SECRET_SETTING_KEYS = {
    "twilio_auth_token",
    "resend_api_key",
    "meta_whatsapp_token",
    "n8n_whatsapp_webhook",  # may embed auth in the URL query string
    "api_key",  # business Data API key
}
