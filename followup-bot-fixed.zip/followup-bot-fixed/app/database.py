"""
Database engine — Supabase (PostgreSQL) primary.

Set one of:
  SUPABASE_DB_URL  — Session/Transaction pooler or direct URI from Supabase
  DATABASE_URL     — same (generic)

Example (Supabase → Project Settings → Database → Connection string → URI):
  postgresql://postgres.[ref]:[YOUR-PASSWORD]@aws-0-....pooler.supabase.com:6543/postgres

Or direct:
  postgresql://postgres:[PASSWORD]@db.[ref].supabase.co:5432/postgres

If neither is set, falls back to local SQLite for emergency offline only.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SUPABASE_DB_URL = (
    os.environ.get("SUPABASE_DB_URL")
    or os.environ.get("DATABASE_URL")
    or ""
).strip()

# Supabase sometimes gives postgres:// — SQLAlchemy needs postgresql://
if SUPABASE_DB_URL.startswith("postgres://"):
    SUPABASE_DB_URL = "postgresql://" + SUPABASE_DB_URL[len("postgres://") :]

if SUPABASE_DB_URL:
    DATABASE_URL = SUPABASE_DB_URL
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=10,
    )
    DB_BACKEND = "supabase"
else:
    DB_PATH = os.environ.get("FOLLOWUP_DB", os.path.join(BASE_DIR, "followup_bot.db"))
    DATABASE_URL = f"sqlite:///{DB_PATH}"
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        pool_pre_ping=True,
    )
    DB_BACKEND = "sqlite"

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Create tables if they do not exist (SQLAlchemy). Prefer running supabase SQL migration once."""
    from app import models  # noqa: F401
    Base.metadata.create_all(bind=engine)
    return DB_BACKEND
