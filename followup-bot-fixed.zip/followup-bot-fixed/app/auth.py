"""Auth helpers — native bcrypt (avoids passlib 1.7 + bcrypt 4.x mismatch)."""
from datetime import datetime, timedelta
from typing import Optional
import os
import secrets as _secrets
from jose import JWTError, jwt
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
import bcrypt

from app.database import get_db, BASE_DIR
from app.models import User


def _load_or_create_secret() -> str:
    """
    Resolve the JWT signing secret.

    Priority:
      1. FOLLOWUP_SECRET env var (required for any real deployment — set this!)
      2. A locally persisted, randomly-generated secret (app/.runtime_secret).
         This is created once on first boot and reused after restarts, so a
         forgotten env var never silently falls back to a hardcoded value
         that's identical across every install of this codebase.

    NEVER ships a fixed default — each deployment gets its own secret unless
    FOLLOWUP_SECRET is explicitly set (recommended for production so the
    secret survives redeploys/container rebuilds, not just restarts on the
    same disk).
    """
    env_secret = os.environ.get("FOLLOWUP_SECRET", "").strip()
    if env_secret:
        return env_secret

    secret_path = os.path.join(BASE_DIR, ".runtime_secret")
    try:
        if os.path.exists(secret_path):
            with open(secret_path, "r") as f:
                existing = f.read().strip()
            if existing:
                return existing
        generated = _secrets.token_urlsafe(48)
        with open(secret_path, "w") as f:
            f.write(generated)
        try:
            os.chmod(secret_path, 0o600)
        except Exception:
            pass
        print(
            "⚠️  FOLLOWUP_SECRET is not set. Generated a random secret and saved it to "
            f"{secret_path} for this install. Set FOLLOWUP_SECRET in your environment "
            "before deploying to production (containers/redeploys won't keep this file)."
        )
        return generated
    except Exception:
        # Filesystem not writable (e.g. read-only container) — fall back to an
        # in-memory secret. Sessions won't survive a restart, but at least it's
        # never a shared, guessable default.
        print(
            "⚠️  FOLLOWUP_SECRET is not set and a local secret file could not be created. "
            "Using a random in-memory secret — all sessions will be invalidated on restart. "
            "Set FOLLOWUP_SECRET in your environment to fix this."
        )
        return _secrets.token_urlsafe(48)


SECRET_KEY = _load_or_create_secret()
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token", auto_error=False)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        hp = hashed_password.encode("utf-8") if isinstance(hashed_password, str) else hashed_password
        return bcrypt.checkpw(plain_password.encode("utf-8"), hp)
    except Exception:
        return False


def get_password_hash(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()


async def get_current_user(
    request: Request,
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
):
    if not token:
        token = request.cookies.get("access_token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            return None
    except JWTError:
        return None
    user = get_user_by_email(db, email)
    if user is None or not user.is_active:
        return None
    return user


async def require_user(user: User = Depends(get_current_user)):
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


async def require_admin(user: User = Depends(require_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def require_client(user: User = Depends(require_user)):
    """
    Strict client-only guard for /client/* routes.

    Previously this also allowed role == "admin" through, on the theory that an
    admin might want to preview a client's view. In practice only the dashboard
    route ever checked for that case and redirected; every other /client/*
    route (customers, sequences, messages, settings, add/edit/send/note/visit/
    enroll...) would run with user.business_id == None for an admin — read
    routes came back silently empty and write routes crashed with a raw 500
    (customers.business_id is NOT NULL). Blocking admins here with a normal
    403 is consistent with how require_admin already treats non-admins, and
    is safer than partially-supported "preview" behavior.
    """
    if user.role != "client":
        raise HTTPException(status_code=403, detail="Client access required")
    return user


# --- Simple in-memory login rate limiter -----------------------------------
# Not a substitute for a shared store (Redis) behind multiple workers/replicas,
# but stops trivial unauthenticated brute-forcing of a single-process deploy.
_LOGIN_ATTEMPTS: dict = {}
_LOGIN_MAX_ATTEMPTS = 8
_LOGIN_WINDOW_SECONDS = 15 * 60


def check_login_rate_limit(key: str) -> bool:
    """Returns True if this key (e.g. IP or IP+email) may attempt login now."""
    now = datetime.utcnow().timestamp()
    attempts = [t for t in _LOGIN_ATTEMPTS.get(key, []) if now - t < _LOGIN_WINDOW_SECONDS]
    _LOGIN_ATTEMPTS[key] = attempts
    return len(attempts) < _LOGIN_MAX_ATTEMPTS


def record_login_failure(key: str) -> None:
    now = datetime.utcnow().timestamp()
    _LOGIN_ATTEMPTS.setdefault(key, []).append(now)


def clear_login_failures(key: str) -> None:
    _LOGIN_ATTEMPTS.pop(key, None)
