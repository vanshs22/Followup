"""Seed the database with demo data for Gym + Med Spa examples."""
from datetime import datetime, timedelta
import random
from app.database import SessionLocal, init_db
from app.models import (
    Business, User, Customer, Sequence, SequenceStep,
    CustomerStatus, SequenceType, Channel
)
from app.auth import get_password_hash


def seed():
    init_db()
    db = SessionLocal()

    # Check if already seeded
    if db.query(User).filter(User.email == "admin@followupbot.com").first():
        print("Database already seeded.")
        db.close()
        return

    # ---- Admin User ----
    admin = User(
        email="admin@followupbot.com",
        hashed_password=get_password_hash("admin123"),
        full_name="Platform Admin",
        role="admin",
        business_id=None,
    )
    db.add(admin)

    # ---- Demo Business 1: FitLife Gym ----
    gym = Business(
        name="FitLife Gym",
        industry="gym",
        email="owner@fitlifegym.com",
        phone="+1-555-0101",
        timezone="America/New_York",
        settings={"primary_color": "#10b981"},
    )
    db.add(gym)
    db.flush()

    gym_owner = User(
        email="owner@fitlifegym.com",
        hashed_password=get_password_hash("gym123"),
        full_name="Alex Rivera",
        role="client",
        business_id=gym.id,
    )
    db.add(gym_owner)

    # ---- Demo Business 2: Glow Med Spa ----
    spa = Business(
        name="Glow Med Spa",
        industry="med_spa",
        email="owner@glowmedspa.com",
        phone="+1-555-0202",
        timezone="America/Los_Angeles",
        settings={"primary_color": "#8b5cf6"},
    )
    db.add(spa)
    db.flush()

    spa_owner = User(
        email="owner@glowmedspa.com",
        hashed_password=get_password_hash("spa123"),
        full_name="Jordan Lee",
        role="client",
        business_id=spa.id,
    )
    db.add(spa_owner)

    db.commit()

    # ---- Sequences for Gym ----
    # 1. Post-Visit Follow-up
    seq1 = Sequence(
        business_id=gym.id,
        name="Post-Class Follow-up",
        description="Thank members after a class and encourage the next visit",
        sequence_type=SequenceType.FOLLOW_UP.value,
        is_active=True,
        trigger_rules={},  # Manual or after visit event
    )
    db.add(seq1)
    db.flush()

    steps1 = [
        SequenceStep(
            sequence_id=seq1.id, order=1, delay_days=0, delay_hours=2,
            channel=Channel.SMS.value,
            message_template="Hey {{first_name}}! 💪 Great seeing you at FitLife today. How did you feel after class? Reply and let us know!",
        ),
        SequenceStep(
            sequence_id=seq1.id, order=2, delay_days=2, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="Hi {{first_name}}, ready for your next session? Book now and keep the momentum going → https://fitlife.example/book",
        ),
        SequenceStep(
            sequence_id=seq1.id, order=3, delay_days=5, delay_hours=0,
            channel=Channel.EMAIL.value,
            subject="We miss you at FitLife, {{first_name}}!",
            message_template="Hi {{first_name}},\n\nIt's been a few days since your last visit. Our community is stronger with you in it!\n\nBook your next class: https://fitlife.example/book\n\nSee you soon,\nThe FitLife Team",
        ),
    ]
    db.add_all(steps1)

    # 2. Dormant Member Reactivation
    seq2 = Sequence(
        business_id=gym.id,
        name="Dormant Member Reactivation",
        description="Win back members who haven't visited in 30+ days",
        sequence_type=SequenceType.REACTIVATION.value,
        is_active=True,
        trigger_rules={"days_since_last_visit": 30, "status": "dormant"},
    )
    db.add(seq2)
    db.flush()

    steps2 = [
        SequenceStep(
            sequence_id=seq2.id, order=1, delay_days=0, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="Hey {{first_name}}, we noticed it's been a while since your last visit at FitLife 🏋️. We'd love to see you back! Reply YES for a free class this week.",
        ),
        SequenceStep(
            sequence_id=seq2.id, order=2, delay_days=3, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="{{first_name}}, still thinking about it? Here's 20% off your next month if you come back this week. Use code COMEBACK20",
        ),
        SequenceStep(
            sequence_id=seq2.id, order=3, delay_days=7, delay_hours=0,
            channel=Channel.EMAIL.value,
            subject="We saved your spot, {{first_name}}",
            message_template="Hi {{first_name}},\n\nYour FitLife community misses you. We've reserved a special comeback offer just for you.\n\nClaim it here: https://fitlife.example/comeback\n\nHope to see you soon!",
        ),
        SequenceStep(
            sequence_id=seq2.id, order=4, delay_days=14, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="Last chance {{first_name}}! Your exclusive comeback offer expires in 48 hours. Don't miss out 💪",
        ),
    ]
    db.add_all(steps2)

    # 3. Win-Back (Churned)
    seq3 = Sequence(
        business_id=gym.id,
        name="Win-Back Campaign",
        description="Re-engage fully churned members (90+ days)",
        sequence_type=SequenceType.WIN_BACK.value,
        is_active=True,
        trigger_rules={"days_since_last_visit": 90, "status": "churned"},
    )
    db.add(seq3)
    db.flush()

    steps3 = [
        SequenceStep(
            sequence_id=seq3.id, order=1, delay_days=0, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="{{first_name}}, it's been too long! FitLife has new classes and a special welcome-back gift waiting for you. Interested?",
        ),
        SequenceStep(
            sequence_id=seq3.id, order=2, delay_days=5, delay_hours=0,
            channel=Channel.EMAIL.value,
            subject="A gift is waiting for you at FitLife",
            message_template="Hi {{first_name}},\n\nWe know life gets busy. When you're ready to restart your fitness journey, we're here with open arms and a free personal training session.\n\nRedeem: https://fitlife.example/welcome-back",
        ),
    ]
    db.add_all(steps3)

    # ---- Sequences for Med Spa ----
    seq4 = Sequence(
        business_id=spa.id,
        name="Post-Treatment Follow-up",
        description="Care instructions + rebooking after treatment",
        sequence_type=SequenceType.FOLLOW_UP.value,
        is_active=True,
    )
    db.add(seq4)
    db.flush()

    steps4 = [
        SequenceStep(
            sequence_id=seq4.id, order=1, delay_days=0, delay_hours=4,
            channel=Channel.SMS.value,
            message_template="Hi {{first_name}}! Thank you for visiting Glow Med Spa today. Remember: no intense exercise for 24h and stay hydrated. Questions? Just reply!",
        ),
        SequenceStep(
            sequence_id=seq4.id, order=2, delay_days=7, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="{{first_name}}, how is your skin feeling one week later? We'd love to hear! Also, book your next session for best results → https://glow.example/book",
        ),
        SequenceStep(
            sequence_id=seq4.id, order=3, delay_days=21, delay_hours=0,
            channel=Channel.EMAIL.value,
            subject="Time for your next glow-up, {{first_name}}?",
            message_template="Hi {{first_name}},\n\nMost of our clients book their next treatment around this time for optimal results.\n\nBook now and receive 10% off: https://glow.example/book\n\n— Glow Med Spa",
        ),
    ]
    db.add_all(steps4)

    seq5 = Sequence(
        business_id=spa.id,
        name="Client Reactivation",
        description="Re-engage clients who haven't booked in 45+ days",
        sequence_type=SequenceType.REACTIVATION.value,
        is_active=True,
        trigger_rules={"days_since_last_visit": 45},
    )
    db.add(seq5)
    db.flush()

    steps5 = [
        SequenceStep(
            sequence_id=seq5.id, order=1, delay_days=0, delay_hours=0,
            channel=Channel.SMS.value,
            message_template="Hi {{first_name}}, your skin called — it misses Glow Med Spa ✨. Book this month and enjoy a complimentary add-on. Reply BOOK to schedule.",
        ),
        SequenceStep(
            sequence_id=seq5.id, order=2, delay_days=4, delay_hours=0,
            channel=Channel.EMAIL.value,
            subject="We reserved something special for you",
            message_template="Dear {{first_name}},\n\nIt's been a little while. To welcome you back we're offering a complimentary LED therapy add-on with any treatment this month.\n\nReserve your spot: https://glow.example/return",
        ),
    ]
    db.add_all(steps5)

    db.commit()

    # ---- Seed Customers for Gym ----
    first_names = ["Emma", "Liam", "Olivia", "Noah", "Ava", "Ethan", "Sophia", "Mason",
                   "Isabella", "William", "Mia", "James", "Charlotte", "Benjamin", "Amelia",
                   "Lucas", "Harper", "Henry", "Evelyn", "Alexander"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
                  "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
                  "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"]

    for i in range(40):
        days_ago = random.choice([3, 7, 12, 18, 25, 35, 45, 60, 80, 100, 120, None])
        last_visit = datetime.utcnow() - timedelta(days=days_ago) if days_ago else None
        status = CustomerStatus.NEW.value
        if last_visit:
            d = (datetime.utcnow() - last_visit).days
            if d <= 14:
                status = CustomerStatus.ACTIVE.value
            elif d <= 30:
                status = CustomerStatus.AT_RISK.value
            elif d <= 90:
                status = CustomerStatus.DORMANT.value
            else:
                status = CustomerStatus.CHURNED.value

        c = Customer(
            business_id=gym.id,
            first_name=random.choice(first_names),
            last_name=random.choice(last_names),
            email=f"member{i+1}@example.com",
            phone=f"+1555{1000+i:04d}",
            status=status,
            last_visit=last_visit,
            total_visits=random.randint(1, 50) if last_visit else 0,
            lifetime_value=round(random.uniform(50, 2500), 2),
            source=random.choice(["walk-in", "instagram", "referral", "google", "facebook"]),
            tags=random.sample(["vip", "pt-client", "morning", "student", "corporate"], k=random.randint(0, 2)),
        )
        db.add(c)

    # ---- Seed Customers for Spa ----
    for i in range(25):
        days_ago = random.choice([5, 10, 20, 40, 55, 70, 100, None])
        last_visit = datetime.utcnow() - timedelta(days=days_ago) if days_ago else None
        status = CustomerStatus.NEW.value
        if last_visit:
            d = (datetime.utcnow() - last_visit).days
            if d <= 14:
                status = CustomerStatus.ACTIVE.value
            elif d <= 45:
                status = CustomerStatus.AT_RISK.value
            elif d <= 90:
                status = CustomerStatus.DORMANT.value
            else:
                status = CustomerStatus.CHURNED.value

        c = Customer(
            business_id=spa.id,
            first_name=random.choice(first_names),
            last_name=random.choice(last_names),
            email=f"client{i+1}@example.com",
            phone=f"+1555{2000+i:04d}",
            status=status,
            last_visit=last_visit,
            total_visits=random.randint(1, 20) if last_visit else 0,
            lifetime_value=round(random.uniform(150, 5000), 2),
            source=random.choice(["referral", "instagram", "google", "walk-in"]),
            tags=random.sample(["botox", "filler", "facial", "vip", "membership"], k=random.randint(0, 2)),
        )
        db.add(c)

    db.commit()
    db.close()
    print("Database seeded successfully!")
    print("   Admin:  admin@followupbot.com / admin123")
    print("   Gym:    owner@fitlifegym.com / gym123")
    print("   Spa:    owner@glowmedspa.com / spa123")


if __name__ == "__main__":
    seed()