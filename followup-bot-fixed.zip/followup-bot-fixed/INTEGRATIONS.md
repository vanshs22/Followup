# Messaging integrations (Twilio · Resend · WhatsApp n8n)

FollowUp sends outbound follow-ups and logs inbound replies into the CRM inbox.

## Channel map

| Channel | Outbound | Inbound webhook |
|---------|----------|-----------------|
| **SMS** | Twilio REST API | `POST /webhooks/twilio/sms` |
| **Email** | Resend API | `POST /webhooks/resend` |
| **WhatsApp** | n8n webhook **or** Meta Cloud API **or** Twilio WA | `POST /webhooks/n8n/whatsapp` · `POST /webhooks/meta/whatsapp` · `POST /webhooks/twilio/whatsapp` |

Keys are set by **platform admin** per client (Admin → Client account → messaging keys). Clients only see “connected / not connected”.

---

## 1. Twilio SMS (phone)

Admin sets for the client:
- `twilio_account_sid`
- `twilio_auth_token`
- `twilio_from_number` (e.g. `+15551234567`)

**Twilio Console → Phone number → Messaging webhook**

```
POST https://YOUR_DOMAIN/webhooks/twilio/sms
```

Method: HTTP POST. FollowUp returns empty TwiML `<Response></Response>`.

Inbound `From` + `Body` are matched to a customer by phone → logged in Inbox → wins / STOP / auto-reply rules or AI.

---

## 2. Resend (email)

Admin sets:
- `resend_api_key`
- `resend_from_email` (verified domain, e.g. `FitLife <hello@yourdomain.com>`)

Optional inbound events:

```
POST https://YOUR_DOMAIN/webhooks/resend
```

Body examples: `{ "from": "client@mail.com", "text": "yes book me" }` or Resend event envelope with `data`.

---

## 3. WhatsApp via n8n (recommended — matches your Coach AI Chatbot)

Your attached **Coach AI Chatbot** workflow is the reference:

```
WhatsApp Trigger → If (has messages) → AI Agent (OpenAI + Memory + Pinecone) → Send message
```

### Option A — Log everything into FollowUp CRM (bridge)

Add an **HTTP Request** node after WhatsApp Trigger (and/or after AI):

**POST** `https://YOUR_DOMAIN/webhooks/n8n/whatsapp`

Body (JSON) — either simple or **native trigger shape** (both work):

```json
{
  "messages": [{{ $json.messages }}],
  "contacts": [{{ $json.contacts }}],
  "metadata": {{ $json.metadata }},
  "business_id": 1
}
```

Or simple:

```json
{
  "from": "{{ $json.messages[0].from }}",
  "message": "{{ $json.messages[0].text.body }}",
  "business_id": 1
}
```

FollowUp will:
1. Match customer by phone  
2. Store inbound in Inbox  
3. Mark wins / opt-out  
4. Fire **keyword rules** and/or **AI auto-reply** (per admin mode for that client)

You can still run your Coach AI Agent in n8n for coaching answers; FollowUp owns CRM + reactivation.

### Option B — FollowUp sends outbound WhatsApp through n8n

Admin sets **n8n WhatsApp webhook** URL for the client to a workflow that ends in **WhatsApp → Send message**.

Outbound payload from FollowUp includes fields your Send node can map:

| Field | Use in n8n |
|-------|------------|
| `recipientPhoneNumber` / `to` / `phone` | Recipient |
| `textBody` / `message` / `text` | Message body |
| `phone_number_id` | Meta phone number id (if needed) |

Example n8n flow for outbound only:

```
Webhook (POST) → WhatsApp Send message
  phoneNumberId = {{ $json.phone_number_id }}
  recipientPhoneNumber = {{ $json.recipientPhoneNumber }}
  textBody = {{ $json.textBody }}
```

### Option C — Meta Cloud API direct

Admin sets `meta_whatsapp_token` + `meta_whatsapp_phone_id`.  
Webhook verify: `GET /webhooks/meta/whatsapp` with `META_WHATSAPP_VERIFY_TOKEN` (default `followup_verify`).  
Messages: `POST /webhooks/meta/whatsapp`.

### Option D — Twilio WhatsApp

Admin sets `twilio_whatsapp_from` (e.g. `whatsapp:+1415...`) using same Account SID/token.  
Inbound: `POST /webhooks/twilio/whatsapp`.

---

## 4. Knowledge Pusher (your second workflow)

Your **Knowledge Pusher** (Drive → Pinecone) stays in n8n. It feeds the Coach AI Chatbot knowledge base. FollowUp does not replace Pinecone; it stores **customers, visits, enrollments, message logs**.

Typical architecture:

```
Google Drive docs ──► Knowledge Pusher ──► Pinecone
                                              │
WhatsApp user ──► n8n Coach AI (RAG) ─────────┘
                 │
                 └──► POST /webhooks/n8n/whatsapp ──► FollowUp CRM Inbox + wins
FollowUp bot ──► Twilio SMS / Resend email / n8n WhatsApp outbound
```

---

## Env vars (optional platform defaults)

```bash
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_FROM_NUMBER=
TWILIO_WHATSAPP_FROM=
RESEND_API_KEY=
RESEND_FROM_EMAIL=
N8N_WHATSAPP_WEBHOOK=
META_WHATSAPP_TOKEN=
META_WHATSAPP_PHONE_ID=
META_WHATSAPP_VERIFY_TOKEN=followup_verify
FOLLOWUP_SIMULATE=true   # simulate when keys missing or auth 401
```

Per-client overrides in Admin UI win over env for that business.
