-- FollowUp CRM schema for Supabase (PostgreSQL)
-- Run in Supabase SQL Editor OR: supabase db push / psql $DATABASE_URL -f this file

BEGIN;

CREATE TABLE IF NOT EXISTS businesses (
  id SERIAL PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  industry VARCHAR(100) DEFAULT 'gym',
  email VARCHAR(200),
  phone VARCHAR(50),
  timezone VARCHAR(50) DEFAULT 'UTC',
  logo_url VARCHAR(500),
  settings JSONB DEFAULT '{}'::jsonb,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(200) NOT NULL UNIQUE,
  hashed_password VARCHAR(255) NOT NULL,
  full_name VARCHAR(200),
  role VARCHAR(20) DEFAULT 'client',
  business_id INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  is_active BOOLEAN DEFAULT TRUE,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_users_email ON users(email);
CREATE INDEX IF NOT EXISTS ix_users_business_id ON users(business_id);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  email VARCHAR(200),
  phone VARCHAR(50),
  status VARCHAR(20) DEFAULT 'new',
  tags JSONB DEFAULT '[]'::jsonb,
  last_visit TIMESTAMPTZ,
  total_visits INTEGER DEFAULT 0,
  lifetime_value DOUBLE PRECISION DEFAULT 0,
  source VARCHAR(100),
  notes TEXT,
  custom_fields JSONB DEFAULT '{}'::jsonb,
  opted_out BOOLEAN DEFAULT FALSE,
  last_reply_at TIMESTAMPTZ,
  win_count INTEGER DEFAULT 0,
  address VARCHAR(300),
  city VARCHAR(100),
  birthday TIMESTAMPTZ,
  assigned_to VARCHAR(200),
  next_appointment TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_customers_business_id ON customers(business_id);
CREATE INDEX IF NOT EXISTS ix_customers_email ON customers(email);
CREATE INDEX IF NOT EXISTS ix_customers_phone ON customers(phone);
CREATE INDEX IF NOT EXISTS ix_customers_status ON customers(status);
CREATE INDEX IF NOT EXISTS ix_customers_last_visit ON customers(last_visit);

CREATE TABLE IF NOT EXISTS customer_notes (
  id SERIAL PRIMARY KEY,
  business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_customer_notes_customer_id ON customer_notes(customer_id);

CREATE TABLE IF NOT EXISTS sequences (
  id SERIAL PRIMARY KEY,
  business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  sequence_type VARCHAR(50) DEFAULT 'follow_up',
  is_active BOOLEAN DEFAULT TRUE,
  is_template BOOLEAN DEFAULT FALSE,
  trigger_rules JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_sequences_business_id ON sequences(business_id);

CREATE TABLE IF NOT EXISTS sequence_steps (
  id SERIAL PRIMARY KEY,
  sequence_id INTEGER NOT NULL REFERENCES sequences(id) ON DELETE CASCADE,
  "order" INTEGER DEFAULT 1,
  delay_days INTEGER DEFAULT 0,
  delay_hours INTEGER DEFAULT 0,
  channel VARCHAR(20) DEFAULT 'sms',
  subject VARCHAR(300),
  message_template TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE
);
CREATE INDEX IF NOT EXISTS ix_sequence_steps_sequence_id ON sequence_steps(sequence_id);

CREATE TABLE IF NOT EXISTS enrollments (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  sequence_id INTEGER NOT NULL REFERENCES sequences(id) ON DELETE CASCADE,
  status VARCHAR(20) DEFAULT 'active',
  current_step INTEGER DEFAULT 0,
  enrolled_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  next_action_at TIMESTAMPTZ,
  metadata JSONB DEFAULT '{}'::jsonb,
  won_at TIMESTAMPTZ,
  win_note VARCHAR(300)
);
CREATE INDEX IF NOT EXISTS ix_enrollments_customer_id ON enrollments(customer_id);
CREATE INDEX IF NOT EXISTS ix_enrollments_status ON enrollments(status);

CREATE TABLE IF NOT EXISTS message_logs (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  enrollment_id INTEGER REFERENCES enrollments(id) ON DELETE SET NULL,
  channel VARCHAR(20),
  direction VARCHAR(10) DEFAULT 'outbound',
  subject VARCHAR(300),
  content TEXT,
  status VARCHAR(20) DEFAULT 'pending',
  provider_detail VARCHAR(300),
  external_id VARCHAR(200),
  sent_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  opened_at TIMESTAMPTZ,
  replied_at TIMESTAMPTZ,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_message_logs_customer_id ON message_logs(customer_id);
CREATE INDEX IF NOT EXISTS ix_message_logs_external_id ON message_logs(external_id);

CREATE TABLE IF NOT EXISTS auto_reply_rules (
  id SERIAL PRIMARY KEY,
  business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name VARCHAR(200) DEFAULT 'Rule',
  keywords JSONB DEFAULT '[]'::jsonb,
  channel VARCHAR(20) DEFAULT 'any',
  reply_channel VARCHAR(20) DEFAULT 'same',
  reply_template TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  priority INTEGER DEFAULT 10,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_auto_reply_rules_business_id ON auto_reply_rules(business_id);

CREATE TABLE IF NOT EXISTS activity_logs (
  id SERIAL PRIMARY KEY,
  business_id INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100),
  details TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMIT;
