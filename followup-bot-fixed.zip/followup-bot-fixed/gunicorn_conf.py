"""
Gunicorn configuration for production deployment.

Runs FastAPI (app.main:app) behind Uvicorn workers managed by Gunicorn.

Override via environment variables:
  PORT            - bind port (default 8000)
  WEB_CONCURRENCY - number of worker processes (default: cpu_count * 2 + 1, capped at 4)
"""
import multiprocessing
import os

bind = f"0.0.0.0:{os.environ.get('PORT', '8000')}"

worker_class = "uvicorn.workers.UvicornWorker"

_default_workers = min(multiprocessing.cpu_count() * 2 + 1, 4)
workers = int(os.environ.get("WEB_CONCURRENCY", _default_workers))

timeout = 60

accesslog = "-"
errorlog = "-"
