# Demo test script (simulation mode)

Use this after `uvicorn` is running. **No real SMS/email/WhatsApp required.**

## 1. Start

```bash
cd followup-bot
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Browser: http://127.0.0.1:8000  
First launch seeds demo data and prints logins in the terminal.

---

## 2. Admin demo (5 min)

Login: `admin@followupbot.com` / `admin123`

1. **Overview** — platform numbers, recent activity  
2. Click **Run global bot** (or similar) if shown — both businesses process  
3. **Client accounts** — open **FitLife Gym**  
4. See stats, users, sequences, messaging status  
5. Optionally set **AI modes** (template / ai / both) — leave keys empty for simulate  
6. Sign out  

---

## 3. Gym client demo (15 min)

Login: `owner@fitlifegym.com` / `gym123`

### Home
- Status counts, channel pills (pending/connected)
- **Step 1–2–3** guide
- Click **Run Bot Now** — note enrolled / simulated counts

### Import data
- Optional: upload a tiny CSV:

```csv
first_name,last_name,email,phone,last_visit
Demo,Visitor,demo.visitor@example.com,+15550001111,2026-04-01
```

### Customer database
- Filter by **Dormant** or **At risk**
- Open any person
- **Record check-in**
- **Add note**
- **Send message** (SMS) → simulated, appears in conversation
- **Enroll** in a sequence

### Follow-up flows
- Open an existing sequence (steps listed)
- **New sequence** → name + check **Generate steps with AI** → Create
- **AI rewrite steps** or **Add step**

### Inbox
- Filter outbound / inbound
- Find your simulated send

### Performance
- Channel / status stats, wins list

### Settings
- Generate **API key** (copy it)
- Add auto-reply rule keywords e.g. `book,yes`

---

## 4. Fake inbound (terminal)

Replace phone with one you saw on a customer (or the CSV one):

```bash
# Positive reply → win
curl -X POST http://127.0.0.1:8000/webhooks/n8n/whatsapp \
  -H "Content-Type: application/json" \
  -d '{"from":"+15550001111","message":"yes I want to book","business_id":1}'

# Opt-out
curl -X POST http://127.0.0.1:8000/webhooks/twilio/sms \
  -d "From=%2B15550001111&Body=STOP&MessageSid=SMdemo1"
```

Refresh **Inbox** and that customer’s page — win count / opted out.

---

## 5. API (optional)

```bash
# KEY from Settings
curl -X POST http://127.0.0.1:8000/api/customers/upsert \
  -H "X-API-Key: KEY" -H "Content-Type: application/json" \
  -d '{"first_name":"Api","email":"api.demo@example.com","phone":"+15552223333","external_id":"demo-api-1"}'
```

---

## 6. Spa isolation check

Login: `owner@glowmedspa.com` / `spa123`  
- Own dashboard works  
- `/admin` should be blocked  
- Only spa customers, not gym  

---

## Pass criteria

| Action | Expected |
|--------|----------|
| First start | Seed message in terminal |
| Run Bot | enrolled + simulated > 0 (or 0 if already processed) |
| Send message | Conversation shows outbound simulated |
| Inbound “yes” | matched true, win |
| STOP | opted out |
| Import CSV | new row in database |
| Spa vs gym | no cross access |

When this works, you are ready to demo to a pilot client (still simulated until you add real Twilio/Resend/n8n keys in Admin).
