# CHANGELOG — Security & Reliability Fixes

Applied against the codebase audited in `FOLLOWUP_BOT_AUDIT.md`. Every file still
compiles clean (`python3 -m py_compile app/*.py`). Not runtime-tested end-to-end
(no network to install dependencies in the environment this was built in) — run
through `DEMO.md`'s click-through script once before trusting this in production.

## Critical

- **Automated bot runs (the big one).** Added APScheduler, started on app
  boot, running the same logic as "Run global bot" every
  `BOT_SCHEDULER_INTERVAL_MINUTES` (default 10). Previously sequences only
  ever sent when a human clicked a button — the "automation" didn't
  automate anything on its own. Disable with `BOT_SCHEDULER_ENABLED=false`
  if you're driving runs from an external cron/n8n instead.
  — `app/main.py` (`on_startup`, `on_shutdown`, `_run_bot_for_all_businesses`)

- **No more hardcoded JWT secret.** `FOLLOWUP_SECRET` now has no fixed
  fallback. If unset, a random secret is generated once and persisted to
  `app/.runtime_secret` (gitignored) so every install gets its own — no two
  deployments of this codebase can ever share a guessable default again.
  — `app/auth.py` (`_load_or_create_secret`)

- **Twilio inbound webhooks now scoped to the right business.**
  `record_inbound_reply()` was previously called with no `business_id` for
  Twilio SMS/WhatsApp, so it matched replies against *every customer across
  every tenant* by phone digits alone. Now resolves the receiving business
  from the Twilio `To` number first. Also added Twilio signature
  verification (`X-Twilio-Signature`) so the webhook can't be spoofed by
  someone who just learns the URL.
  — `app/main.py` (`twilio_sms_webhook`, `twilio_whatsapp_webhook`),
    `app/integrations.py` (`find_business_by_twilio_number`, `verify_twilio_signature`)

- **Meta webhook signature verification added**, and the guessable default
  verify token (`"followup_verify"`) removed — verification now requires
  `META_WHATSAPP_VERIFY_TOKEN` and `META_APP_SECRET` to be explicitly set.
  — `app/main.py` (`meta_whatsapp_webhook`, `meta_whatsapp_verify`),
    `app/integrations.py` (`verify_meta_signature`)

- **Force-enroll no longer creates duplicate active enrollments.**
  `enroll_customer(force=True)` — used by the manual "Enroll" button —
  previously skipped the "already active in this exact sequence" check
  entirely, so clicking Enroll on a sequence the customer was already in
  created a second parallel `Enrollment`, and `process_pending_steps` sent
  every step of that sequence twice. Now cancels the prior run first.
  — `app/bot_engine.py` (`enroll_customer`)

- **New client businesses can actually be onboarded.** There was no
  endpoint or UI to create a business + owner user — only the two seeded
  demo businesses could ever exist. Added
  **Admin → Businesses → New client business**, which creates the business
  and a client-role owner login with a generated temp password (shown once).
  — `app/main.py` (`admin_create_business`), `app/templates/admin/businesses.html`

## High

- **Admins can no longer break into `/client/*` routes.** `require_client`
  previously allowed `role == "admin"` through, but only the dashboard route
  actually checked for and redirected that case — every other client route
  (add/edit customer, notes, sequences, settings...) ran with
  `business_id = None`, silently returning empty data on reads and throwing
  an unhandled 500 on writes (`customers.business_id` is `NOT NULL`).
  `require_client` is now strict — non-clients get a normal 403, same as
  `require_admin` already does for non-admins.
  — `app/auth.py` (`require_client`)

- **CSV/API bulk import is no longer O(rows × existing customers) with a
  commit per row.** Added an in-memory `CustomerIndex` built once per import
  (external_id / email / normalized phone), so each row's lookup is O(1)
  instead of a full Python-side scan of every existing customer. Commits are
  now batched (every 200 rows) instead of once per row.
  — `app/data_sync.py` (`CustomerIndex`, `find_customer`, `upsert_customer`, `import_csv_rows`)

- **Provider credentials encrypted at rest.** Twilio auth token, Resend API
  key, Meta token, AI API key, and the client's own Data API key were all
  stored as plaintext JSON in `businesses.settings`. Now encrypted with
  Fernet before saving and transparently decrypted where needed (sending,
  API auth, and — only for the client's own Data API key — showing it back
  to them on their own settings page). Existing plaintext values from older
  installs still read correctly and get encrypted the next time that field
  is saved.
  — new `app/crypto.py`; wired into `app/integrations.py`, `app/ai_writer.py`, `app/main.py`

- **Basic login rate limiting** (in-memory, keyed by IP+email — a
  single-process mitigation, not a substitute for a shared store behind
  multiple workers) and **demo credentials hidden by default control**:
  the login page's visible `admin123`/`gym123`/`spa123` block is now gated
  behind `SHOW_DEMO_LOGINS` (defaults to shown, for local/demo use).
  — `app/auth.py` (rate limiter), `app/main.py` (`login_submit`), `app/templates/auth/login.html`

## Medium

- **Row-locking on concurrent bot runs (Postgres only).**
  `process_pending_steps` now uses `SELECT ... FOR UPDATE SKIP LOCKED` when
  running against Supabase/Postgres, so two overlapping runs (e.g. a
  client's "Run Bot Now" and the platform's "Run global bot" firing close
  together) can't both grab and double-send the same due enrollment.
  SQLite (local/demo mode) doesn't support this and is left as-is.
  — `app/bot_engine.py` (`process_pending_steps`)

- **Friendlier errors on `/client` and `/admin` routes.** A global
  `HTTPException` handler now renders a proper error page for browser-facing
  routes instead of a bare `{"detail": "..."}` JSON blob mid a form flow.
  `/api/*` and `/webhooks/*` still get JSON as before. As a side effect,
  this also fixes a separate bug: an expired session on any `/client` or
  `/admin` page previously showed raw JSON with no redirect — it now
  redirects to `/login` properly.
  — `app/main.py` (`friendly_http_exception_handler`), new `app/templates/error.html`

- **n8n bridge workflow** now has a visible node note explaining that
  `business_id` is hardcoded to `1` and needs to be changed per business if
  you duplicate the workflow for additional clients (the JSON body itself
  is unchanged/still valid — the note doesn't affect the request).
  — `n8n-followup-whatsapp-bridge.json`

## The concrete "silent success" wiring bug

The backend redirected with `?added=1`, `?enrolled=1`, `?note=1`, `?saved=1`,
and `?visit=1` after successful actions, but no template ever checked any of
these five params — so adding a customer, enrolling someone in a sequence,
adding a note, editing a profile, and recording a check-in all silently
succeeded with **zero visual feedback**. Added the matching banners.
Also fixed `manual_enroll` to reflect the real outcome (it previously always
redirected with `?enrolled=1` even when the customer was opted out and
enrollment silently didn't happen).
— `app/templates/client/customers.html`, `app/templates/client/customer_detail.html`, `app/main.py` (`manual_enroll`)

## Cleanup

- Removed the orphaned hidden `#csv-import-form` in `customers.html` (no
  file input, never wired to any JS — dead markup from an earlier iteration).
- Added `.gitignore` (was missing — `.env`, the local SQLite file, and the
  new `app/.runtime_secret` should never be committed).

## Not done in this pass (documented, not fixed)

These are real, lower-urgency findings from the audit that weren't touched,
to keep this patch focused and reviewable:

- No CSRF tokens on state-changing forms (partially mitigated by
  `SameSite=Lax` cookies already in place).
- No delete/edit for customers, sequences, or individual sequence steps.
- No pagination (customers capped at 200 rows, messages at 150).
- No self-serve "change password" / forgot-password flow.
- `add_customer`/`edit_customer` still don't dedupe by email/phone the way
  the CSV import path now does.
