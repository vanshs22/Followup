"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-08-10

Hand-written migration mirroring app/models.py exactly (Business, User,
Customer, CustomerNote, Sequence, SequenceStep, Enrollment, MessageLog,
AutoReplyRule, ActivityLog). All enum-backed columns are stored as plain
String in the models (values via .value), so no native Postgres ENUM
types are created here — this matches SQLite and Postgres identically.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "businesses",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=200), nullable=False),
        sa.Column("industry", sa.String(length=100), server_default="gym"),
        sa.Column("email", sa.String(length=200), nullable=True),
        sa.Column("phone", sa.String(length=50), nullable=True),
        sa.Column("timezone", sa.String(length=50), server_default="UTC"),
        sa.Column("logo_url", sa.String(length=500), nullable=True),
        sa.Column("settings", sa.JSON(), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_businesses_id", "businesses", ["id"])

    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(length=200), nullable=False),
        sa.Column("hashed_password", sa.String(length=255), nullable=False),
        sa.Column("full_name", sa.String(length=200), nullable=True),
        sa.Column("role", sa.String(length=20), server_default="client"),
        sa.Column("business_id", sa.Integer(), sa.ForeignKey("businesses.id"), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true()),
        sa.Column("last_login", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_users_id", "users", ["id"])
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    op.create_table(
        "customers",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("business_id", sa.Integer(), sa.ForeignKey("businesses.id"), nullable=False),
        sa.Column("first_name", sa.String(length=100), nullable=True),
        sa.Column("last_name", sa.String(length=100), nullable=True),
        sa.Column("email", sa.String(length=200), nullable=True),
        sa.Column("phone", sa.String(length=50), nullable=True),
        sa.Column("status", sa.String(length=20), server_default="new"),
        sa.Column("tags", sa.JSON(), nullable=True),
        sa.Column("last_visit", sa.DateTime(), nullable=True),
        sa.Column("total_visits", sa.Integer(), server_default="0"),
        sa.Column("lifetime_value", sa.Float(), server_default="0.0"),
        sa.Column("source", sa.String(length=100), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("custom_fields", sa.JSON(), nullable=True),
        sa.Column("opted_out", sa.Boolean(), server_default=sa.false()),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true()),
        sa.Column("last_reply_at", sa.DateTime(), nullable=True),
        sa.Column("win_count", sa.Integer(), server_default="0"),
        sa.Column("address", sa.String(length=300), nullable=True),
        sa.Column("city", sa.String(length=100), nullable=True),
        sa.Column("birthday", sa.DateTime(), nullable=True),
        sa.Column("assigned_to", sa.String(length=200), nullable=True),
        sa.Column("next_appointment", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_customers_id", "customers", ["id"])
    op.create_index("ix_customers_business_id", "customers", ["business_id"])
    op.create_index("ix_customers_email", "customers", ["email"])
    op.create_index("ix_customers_phone", "customers", ["phone"])
    op.create_index("ix_customers_status", "customers", ["status"])
    op.create_index("ix_customers_last_visit", "customers", ["last_visit"])

    op.create_table(
        "customer_notes",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("business_id", sa.Integer(), sa.ForeignKey("businesses.id"), nullable=False),
        sa.Column("customer_id", sa.Integer(), sa.ForeignKey("customers.id"), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_customer_notes_id", "customer_notes", ["id"])
    op.create_index("ix_customer_notes_customer_id", "customer_notes", ["customer_id"])

    op.create_table(
        "sequences",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("business_id", sa.Integer(), sa.ForeignKey("businesses.id"), nullable=False),
        sa.Column("name", sa.String(length=200), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("sequence_type", sa.String(length=50), server_default="follow_up"),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true()),
        sa.Column("is_template", sa.Boolean(), server_default=sa.false()),
        sa.Column("trigger_rules", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_sequences_id", "sequences", ["id"])

    op.create_table(
        "sequence_steps",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("sequence_id", sa.Integer(), sa.ForeignKey("sequences.id"), nullable=False),
        sa.Column("order", sa.Integer(), server_default="1"),
        sa.Column("delay_days", sa.Integer(), server_default="0"),
        sa.Column("delay_hours", sa.Integer(), server_default="0"),
        sa.Column("channel", sa.String(length=20), server_default="sms"),
        sa.Column("subject", sa.String(length=300), nullable=True),
        sa.Column("message_template", sa.Text(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true()),
    )
    op.create_index("ix_sequence_steps_id", "sequence_steps", ["id"])

    op.create_table(
        "enrollments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("customer_id", sa.Integer(), sa.ForeignKey("customers.id"), nullable=False),
        sa.Column("sequence_id", sa.Integer(), sa.ForeignKey("sequences.id"), nullable=False),
        sa.Column("status", sa.String(length=20), server_default="active"),
        sa.Column("current_step", sa.Integer(), server_default="0"),
        sa.Column("enrolled_at", sa.DateTime(), nullable=True),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
        sa.Column("next_action_at", sa.DateTime(), nullable=True),
        sa.Column("metadata", sa.JSON(), nullable=True),
        sa.Column("won_at", sa.DateTime(), nullable=True),
        sa.Column("win_note", sa.String(length=300), nullable=True),
    )
    op.create_index("ix_enrollments_id", "enrollments", ["id"])
    op.create_index("ix_enrollments_customer_id", "enrollments", ["customer_id"])
    op.create_index("ix_enrollments_status", "enrollments", ["status"])

    op.create_table(
        "message_logs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("customer_id", sa.Integer(), sa.ForeignKey("customers.id"), nullable=False),
        sa.Column("enrollment_id", sa.Integer(), sa.ForeignKey("enrollments.id"), nullable=True),
        sa.Column("channel", sa.String(length=20), nullable=True),
        sa.Column("direction", sa.String(length=10), server_default="outbound"),
        sa.Column("subject", sa.String(length=300), nullable=True),
        sa.Column("content", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=20), server_default="pending"),
        sa.Column("provider_detail", sa.String(length=300), nullable=True),
        sa.Column("external_id", sa.String(length=200), nullable=True),
        sa.Column("sent_at", sa.DateTime(), nullable=True),
        sa.Column("delivered_at", sa.DateTime(), nullable=True),
        sa.Column("opened_at", sa.DateTime(), nullable=True),
        sa.Column("replied_at", sa.DateTime(), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_message_logs_id", "message_logs", ["id"])
    op.create_index("ix_message_logs_customer_id", "message_logs", ["customer_id"])
    op.create_index("ix_message_logs_external_id", "message_logs", ["external_id"])

    op.create_table(
        "auto_reply_rules",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("business_id", sa.Integer(), sa.ForeignKey("businesses.id"), nullable=False),
        sa.Column("name", sa.String(length=200), server_default="Rule"),
        sa.Column("keywords", sa.JSON(), nullable=True),
        sa.Column("channel", sa.String(length=20), server_default="any"),
        sa.Column("reply_channel", sa.String(length=20), server_default="same"),
        sa.Column("reply_template", sa.Text(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true()),
        sa.Column("priority", sa.Integer(), server_default="10"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_auto_reply_rules_id", "auto_reply_rules", ["id"])
    op.create_index("ix_auto_reply_rules_business_id", "auto_reply_rules", ["business_id"])

    op.create_table(
        "activity_logs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("business_id", sa.Integer(), sa.ForeignKey("businesses.id"), nullable=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("action", sa.String(length=100), nullable=True),
        sa.Column("details", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_activity_logs_id", "activity_logs", ["id"])


def downgrade() -> None:
    op.drop_table("activity_logs")
    op.drop_table("auto_reply_rules")
    op.drop_table("message_logs")
    op.drop_table("enrollments")
    op.drop_table("sequence_steps")
    op.drop_table("sequences")
    op.drop_table("customer_notes")
    op.drop_table("customers")
    op.drop_table("users")
    op.drop_table("businesses")
