# Supabase setup (demo data)

## 1. Create project

1. https://supabase.com → New project  
2. Save the **database password**

## 2. Create tables

**Option A — SQL Editor (recommended once)**

1. Supabase → **SQL** → New query  
2. Paste contents of `supabase/migrations/001_initial_schema.sql`  
3. Run  

**Option B — let the app create tables**

SQLAlchemy `create_all` on startup also creates missing tables if the role can DDL.

## 3. Connection string

Supabase → **Project Settings → Database**:

- Prefer **Connection pooling → Session** URI (port **6543**), or  
- **Direct** URI (port **5432**)

Copy into `.env` in `followup-bot/`:

```bash
cp .env.example .env
# edit SUPABASE_DB_URL=postgresql://...
```

Replace password and project ref. If the URI starts with `postgres://`, the app rewrites it to `postgresql://`.

## 4. Install & run

```bash
cd followup-bot
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

On first start you should see:

```text
Database backend: supabase
✅ Database seeded successfully!
   Admin:  admin@followupbot.com / admin123
   Gym:    owner@fitlifegym.com / gym123
   Spa:    owner@glowmedspa.com / spa123
```

Seed is **idempotent** (skips if admin user already exists).

## 5. Verify in Supabase

**Table Editor** → you should see:

- businesses (FitLife Gym, Glow Med Spa)
- users (3 logins)
- customers (~65)
- sequences, sequence_steps
- auto_reply_rules (after startup)

## 6. Reset demo data

In SQL Editor:

```sql
TRUNCATE activity_logs, message_logs, enrollments, sequence_steps, sequences,
  customer_notes, customers, auto_reply_rules, users, businesses
  RESTART IDENTITY CASCADE;
```

Restart the app to re-seed.

## Demo logins (same as before)

| Role | Email | Password |
|------|--------|----------|
| Admin | admin@followupbot.com | admin123 |
| Gym | owner@fitlifegym.com | gym123 |
| Spa | owner@glowmedspa.com | spa123 |
